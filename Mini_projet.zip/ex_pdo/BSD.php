<?php 
 session_start();
 include 'function.php';
 ?>
<html>
<head>
   <meta charset="utf-8">
  <title>Bulletin</title>
 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="style.css">

</head>

<body >
  
  <nav class="menu">
   
   <ul>
      <a class="menu-item" href="etudiants.php">Etudiants</a>
    </li>
     <li>
     <a class="menu-item" href="professeur.php">
     Professeurs</a>
     <a class="menu-item" href="code.php">
     Code source</a>
     
     
     </li>


   </ul>  
 </nav>
       
 <center>
    <h3 align="center" style="margin-top: 60px;"><em><b>ROYALE MAROC</b></em></h3>
    <table align="center" style="margin-top: 50px;">

        <form action="" method="POST"> 

         
          <tr><td>Filière:</td>
              <td><select class="form-select" name="filiere">
                    <option>Séléctionner votre filière</option>
                    <?php
                     $con=connection('gestionnotes') or die(mysql_error());;
                     $requet="select * from classes" ;
                      $data=mysqli_query($con,$requet);
                      while ($filiere=mysqli_fetch_array($data)) 
                              echo "<option>$filiere[1]</option>";
                      
                       ?>
                  </select>
              </td></tr>
          <tr><td>Code Nationel:</td>
              <td><select class="form-select  mb-3" name="cne">
                    <option>Séléctionnez CNE</option>
                     <?php
                     $cn0=connection('gestionnotes') or die(mysql_error());;
                     $requete="select * from etudiants" ;
                      $data=mysqli_query($cn0,$requete);
                      while ($code=mysqli_fetch_array($data)) 
                              echo "<option>$code[0]</option>";
                      
                       ?>
                  
              </select></td>
          </tr> 
          <tr>
            <TD>Nom et Prénom:</TD>
            <td><input type="text" class="form-control" name="nomP" placeholder="ESSALAMA KAMAL" ></td><td></td>
            
            <td> <button class="btn btn-primary" name="ok"><i class="bi bi-search"> 
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
              <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
</svg></i></button></td>
          </tr>
          
        
    </table>
  </center>
    
    <table class="table " style="width: 50%; margin-top: 25px; " align="center">
      <tr class="table-dark"><th>Matière</th><th>Note</th><th>Résultat</th></tr>

      <?php 

      if (isset($_POST['ok'])) {
        if (!empty($_POST['filiere']) && !empty($_POST['cne']) && !empty($_POST['nomP'])) {

           $cn=connection('gestionnotes') or die(mysql_error());;
           $nom=$_POST['nomP'];
           $cne=$_POST['cne'];
           $filiere=$_POST['filiere'];
           $req="select designation , note
           from matieres m , notes n , etudiants e , classes c  where n.codeMat=m.codeMat
              and e.codeClasse=c.codeClasse
              and n.CNE='$cne'
              and e.nom='$nom'
              and c.filiere='$filiere'";

           $data=mysqli_query($cn,$req);
           while ($donne=mysqli_fetch_array($data)) {
             echo "<tr>
                     <td>".$donne[0]."</td>
                     <td>".$donne[1]."</td>";

                     if ($donne[1]>=12) 
                       echo "<td>V</td>";
                                      
                   
                   elseif($donne[1]>=6 && $donne[1]<12) 
                     echo "<td>R</td>";
                   
                   else
                    echo "<td>NV</td>";
                  echo"</tr>";
                  
            }
            echo "<tr class=table-dark ><td><b>Moyenne</b></td>";
            $re="select avg(note) from notes where CNE='$cne'";
            $data=mysqli_query($cn,$re);
            if ($donnee=mysqli_fetch_array($data)) {
              echo "<td colspan=2>$donnee[0]</td></tr>";}
           }
          
         else 
           echo "<script>alert('Remplir tout les champs')</script>";

        $_SESSION['cnee']=$_POST['cne'];
$_SESSION['filiere']=$_POST['filiere'];
$_SESSION['nom']=$_POST['nomP'];  
        }



     ?>
</table>
   <a href="print.php?cd=$cnee" name="imprimer"  class="btn btn-primary my-2" target="_blank" style="margin-left: 1050px;"> Imprimer</a> 
    
  </form>

</body>
</html>