<?php 
 include 'function.php';
 ?>
<html>
<head>
   <meta charset="utf-8">
  <title>Prof_Note</title>
 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="style.css">

</head>

<body >
      <?php 
  if (isset($_POST['retour'])) {
    header('location:professeur.php');
  }
    
   ?>
              <form method="POST">
              <button class="btn btn-danger" name="retour" style="margin:10px 0px 0px 10px;">Retour</button>
              <button class="btn btn-danger" name="retour" style="margin:10px 0px 0px 10px;"> <a  href="code.php">
     Code source</a></button>
            </form>
 
    <h3 align="center" style="margin-top: 60px;"><em><b>Notations</b></em></h3>
    <table align="center" style="margin-top: 50px;">
        <form action="" method="POST">    
          
          <tr><td>Code Nationel:</td>
              <td><select class="form-select  mb-3" name="cne">
                    <option>Séléctionnez CNE</option>
                     <?php
                     $cn0=connection('gestionnotes');
                     $requete="select CNE from etudiants" ;
                      $data=mysqli_query($cn0,$requete);
                      while ($code=mysqli_fetch_array($data)) 
                              echo "<option>$code[0]</option>";
                      
                       ?>
                  
              </select></td>
          </tr> 
          <tr>
            <TD>Code Matière:</TD>
            <td><select class="form-select  mb-3" name="codeM">
                    <option>Séléctionnez codeM</option>
                     <?php
                     $cn0=connection('gestionnotes');
                     $requete="select codeMat from matieres" ;
                      $data=mysqli_query($cn0,$requete);
                      while ($code=mysqli_fetch_array($data)) 
                              echo "<option>$code[0]</option>";
                      
                       ?>
                  
              </select></td><td></td>
          </tr>
          
          <tr><td>Note:</td>
              <td><input type="text" class="form-control" name="note" placeholder="15.25"></td>
          </tr>
          <tr ><td></td><td></td></tr>

          <tr><td><button class="btn btn-primary" name="ajou">Ajouter</button></td>
            <td><button class="btn btn-secondary" name="mod">Modifier</button></td>
            <td><button class="btn btn-danger" name="supp">Supprimer</button></td></tr>
          
        </form>
    </table>
    <pre>
      

    </pre>
    <center>
    <table class="table " style="width: 50%; margin-top: 25px; " align="center">
      <th>Code Matière</th>
      <th>Désignation</th>
   <?php
      $req="select * from matieres";
    $data=mysqli_query(connection('gestionnotes'),$req);
    while($matiere= mysqli_fetch_array($data))
    {
      echo "<tr>
              <td>".$matiere['0']."</td>
              <td>".$matiere['1']."</td>
            </tr>";
    }
     ?>
    </table></center>
    <?php 
      if (isset($_POST['ajou'])) {
        if (!empty($_POST['codeM']) && !empty($_POST['cne']) && !empty($_POST['note'])) {
        
                  $cn=connection('gestionnotes');
                  $codeM=$_POST['codeM'];
                  $note=$_POST['note'];
                  $cne=$_POST['cne'];
                  $req="insert into notes values('$codeM','$cne',$note)";
                  mysqli_query($cn,$req);
                  echo "<script>alert('Ajout avec succe')</script>";
       }
       else
            echo "<script>alert('Erreur !!!!')</script>";
    }
     if (isset($_POST['mod'])) {
        if (!empty($_POST['codeM']) && !empty($_POST['cne']) && !empty($_POST['note'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeM=$_POST['codeM'];
                  $note=$_POST['note'];
                  $cne=$_POST['cne'];
                  $req="update notes SET note= $note where CNE='$cne'";
                  mysqli_query($cn1,$req);
                  echo "<script>alert('Modification avec succe')</script>";
       }
       else
            echo "<script>alert('Erreur !!!!')</script>";
    }
      if (isset($_POST['supp'])) {
        if (!empty($_POST['cne'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeM=$_POST['codeM'];
                  $note=$_POST['note'];
                  $cne=$_POST['cne'];
                  $req="delete from notes where CNE='$cne'";
                  mysqli_query($cn1,$req);
                  echo "<script>alert('Suppression avec succe')</script>";
       }
       else
            echo "<script>alert('Erreur !!!!')</script>";
    }

    
     ?>
  </body>
  </html>