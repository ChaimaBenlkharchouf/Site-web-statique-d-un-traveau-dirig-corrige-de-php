<?php 
 include 'function.php';
 ?>
<html>
<head>
   <meta charset="utf-8">
  <title>Prof_Classe</title>
 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="style.css">

</head>

<body >
  <?php 
  if (isset($_POST['retour'])) {
    header('location:BSD.php');
  }
    
   ?>
  <nav class="menu">
          <ul>
            <li>
              <form method="POST">
              <button class="btn btn-danger" name="retour" style="margin:10px 0px 0px 10px;">Retour</button>
           
              <button class="btn btn-danger" name="retour" style="margin:10px 0px 0px 10px;"> <a  href="../Mini_project/home.php">
     Accueil</a></button> </li></form>
           <li>
             <a href="notation.php"  class="menu-item">Notation</a>
           </li>
           <li>
             <a href="matiere.php"   class="menu-item">Matière</a>
           </li>
           <li>
             <a href="code.php"   class="menu-item">Code source</a>
           </li>
         </ul>
     </nav>
    <h3 align="center" style="margin-top: 60px;"><em><b>Classes</b></em></h3>
    <table align="center" style="margin-top: 50px;">
        <form action="" method="POST">    
          
          <tr><td>Code Classe:</td>
              <td><input type="text" class="form-control" name="codeC" placeholder="B125"></td>
          </tr> 
          <tr>
            <TD>Filière:</TD>
            <td><input type="text" class="form-control" name="fil" placeholder="genie informatique"  ></td><td></td>
          </tr>
          <tr><td>Numéro:</td>
              <td><input type="text" class="form-control" name="num" placeholder="12"></td>
          </tr>
          <tr ><td></td><td></td></tr>

          <tr><td><button class="btn btn-primary" name="ajou">Ajouter</button></td>
            <td><button class="btn btn-secondary" name="mod">Modifier</button></td>
            <td><button class="btn btn-danger" name="supp">Supprimer</button></td></tr>
          
        </form>
    </table>
    <?php 
      if (isset($_POST['ajou'])) {
        if (!empty($_POST['codeC']) && !empty($_POST['fil']) && !empty($_POST['num'])) {
        
                  $cn=connection('gestionnotes');
                  $codeC=$_POST['codeC'];
                  $fil=$_POST['fil'];
                  $num=$_POST['num'];
                  $req="insert into classes values('$codeC','$fil',$num)";
                  mysqli_query($cn,$req);
                  echo "<script>alert('Ajout avec succe')</script>";
       }
       else
            echo "<script>alert('Erreur !!!!')</script>";
    }
     if (isset($_POST['mod'])) {
        if (!empty($_POST['codeC']) && !empty($_POST['fil']) && !empty($_POST['num'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeC=$_POST['codeC'];
                  $fil=$_POST['fil'];
                  $num=$_POST['num'];
                  $req="update classes SET filiere='$fil' , num=$num where codeClasse='$codeC'";
                  mysqli_query($cn1,$req);
                  echo "<script>alert('Modification avec succe')</script>";
       }
       else
            echo "<script>alert('Erreur !!!!')</script>";
    }
      if (isset($_POST['supp'])) {
        if (!empty($_POST['codeC'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeC=$_POST['codeC'];
                  $fil=$_POST['fil'];
                  $num=$_POST['num'];
                  $req="delete from classes where codeClasse='$codeC'";
                  mysqli_query($cn1,$req);
                  echo "<script>alert('Suppression avec succe')</script>";
       }
       else
            echo "<script>alert('Erreur !!!!')</script>";
    }
     ?>
  </body>
  </html>