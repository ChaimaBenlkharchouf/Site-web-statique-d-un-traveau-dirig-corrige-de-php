
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="../Mini_project/Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>
body{
    width: 100%;
    height: 100vh;
    background: yellow;
    background-position: center;
    background-size: cover;
    padding-left: 8%;
    padding-right: 8%;
    box-sizing: border-box;
}
    </style>
</head>
<body>
<div class="aa">
        <div class="navbar">
            <img src="../Mini_project/img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="../Mini_project/home.php">L'accueil </a></li>
                    <li><a href="../Mini_project/TP.php">Traveau Pratique</a></li>
                    <li><a href="../Mini_project/cours.pdf"  target="_blank">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="./img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece a</h2>
<br>

<pre>
< ?php 

if (isset($_POST['ok'])) {
if (!empty($_POST['filiere']) && !empty($_POST['cne']) && !empty($_POST['nomP'])) {

 $cn=connection('gestionnotes') or die(mysql_error());;
 $nom=$_POST['nomP'];
 $cne=$_POST['cne'];
 $filiere=$_POST['filiere'];
 $req="select designation , note
 from matieres m , notes n , etudiants e , classes c  where n.codeMat=m.codeMat
    and e.codeClasse=c.codeClasse
    and n.CNE='$cne'
    and e.nom='$nom'
    and c.filiere='$filiere'";

 $data=mysqli_query($cn,$req);
 while ($donne=mysqli_fetch_array($data)) {
   echo "< tr>
           < td>".$donne[0]."< /td>
           < td>".$donne[1]."< /td>";

           if ($donne[1]>=12) 
             echo "< td>V< /td>";
                            
         
         elseif($donne[1]>=6 && $donne[1]<12) 
           echo "< td>R</ td>";
         
         else
          echo "<td>NV</td>";
        echo"</tr>";
        
  }
  echo "< tr class=table-dark >< td><b>Moyenne</ b></td>";
  $re="select avg(note) from notes where CNE='$cne'";
  $data=mysqli_query($cn,$re);
  if ($donnee=mysqli_fetch_array($data)) {
    echo "< td colspan=2>$donnee[0]< /td></tr>";}
 }

else 
 echo "< script>alert('Remplir tout les champs')< /script>";

$_SESSION['cnee']=$_POST['cne'];
$_SESSION['filiere']=$_POST['filiere'];
$_SESSION['nom']=$_POST['nomP'];  
}



?>
</pre>
<br>

</div>
</center>
</div>

<div class="col1">
<div  class="carde">
<h2> Code source prufesseur :</h2><br> 

<pre>

if (isset($_POST['ajou'])) {
        if (!empty($_POST['codeC']) && !empty($_POST['fil']) && !empty($_POST['num'])) {
        
                  $cn=connection('gestionnotes');
                  $codeC=$_POST['codeC'];
                  $fil=$_POST['fil'];
                  $num=$_POST['num'];
                  $req="insert into classes values('$codeC','$fil',$num)";
                  mysqli_query($cn,$req);
                  echo "< script>alert('Ajout avec succe')</ script>";
       }
       else
            echo "< script>alert('Erreur !!!!')</ script>";
    }
     if (isset($_POST['mod'])) {
        if (!empty($_POST['codeC']) && !empty($_POST['fil']) && !empty($_POST['num'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeC=$_POST['codeC'];
                  $fil=$_POST['fil'];
                  $num=$_POST['num'];
                  $req="update classes SET filiere='$fil' , num=$num where codeClasse='$codeC'";
                  mysqli_query($cn1,$req);
                  echo "< script>alert('Modification avec succe')< /script>";
       }
       else
            echo "< script>alert('Erreur !!!!')< /script>";
    }
      if (isset($_POST['supp'])) {
        if (!empty($_POST['codeC'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeC=$_POST['codeC'];
                  $fil=$_POST['fil'];
                  $num=$_POST['num'];
                  $req="delete from classes where codeClasse='$codeC'";
                  mysqli_query($cn1,$req);
                  echo "< script>alert('Suppression avec succe')< /script>";
       }
       else
            echo "< script>alert('Erreur !!!!')</ script>";
    }
     ?>
</pre>
</div>

</div>


<div class="col1">
<div  class="carde">
<h2> Code source prufesseur :</h2><br> 

<pre>

if (isset($_POST['ajou'])) {
        if (!empty($_POST['codeC']) && !empty($_POST['fil']) && !empty($_POST['num'])) {
        
                  $cn=connection('gestionnotes');
                  $codeC=$_POST['codeC'];
                  $fil=$_POST['fil'];
                  $num=$_POST['num'];
                  $req="insert into classes values('$codeC','$fil',$num)";
                  mysqli_query($cn,$req);
                  echo "< script>alert('Ajout avec succe')</ script>";
       }
       else
            echo "< script>alert('Erreur !!!!')< /script>";
    }
     if (isset($_POST['mod'])) {
        if (!empty($_POST['codeC']) && !empty($_POST['fil']) && !empty($_POST['num'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeC=$_POST['codeC'];
                  $fil=$_POST['fil'];
                  $num=$_POST['num'];
                  $req="update classes SET filiere='$fil' , num=$num where codeClasse='$codeC'";
                  mysqli_query($cn1,$req);
                  echo "< script>alert('Modification avec succe')< /script>";
       }
       else
            echo "< script>alert('Erreur !!!!')</ script>";
    }
      if (isset($_POST['supp'])) {
        if (!empty($_POST['codeC'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeC=$_POST['codeC'];
                  $fil=$_POST['fil'];
                  $num=$_POST['num'];
                  $req="delete from classes where codeClasse='$codeC'";
                  mysqli_query($cn1,$req);
                  echo "< script>alert('Suppression avec succe')< /script>";
       }
       else
            echo "< script>alert('Erreur !!!!')< /script>";
    }
     ?>
</pre>
</div>

</div>
<div class="col1">
<div  class="carde">
<h2> Code source etudiant :</h2><br> 

<pre>



if (isset($_POST['ajou'])) {
        if (!empty($_POST['codeC']) && !empty($_POST['cne']) && !empty($_POST['nomP'])) {
        
                  $cn=connection('gestionnotes');
                  $codeC=$_POST['codeC'];
                  $nom=$_POST['nomP'];
                  $cne=$_POST['cne'];
                  $req="insert into etudiants values('$cne','$nom','$codeC')";
                  mysqli_query($cn,$req);
                  echo "< script>alert('Ajout avec succe')</ script>";
       } 
       else
            echo "< script>alert('Erreur !!!!')< /script>";
    }
     if (isset($_POST['mod'])) {
        if (!empty($_POST['codeC']) && !empty($_POST['cne']) && !empty($_POST['nomP'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeC=$_POST['codeC'];
                  $nom=$_POST['nomP'];
                  $cne=$_POST['cne'];
                  $req="update etudiants SET nom='$nom' , codeClasse='$codeC' where CNE='$cne'";
                  mysqli_query($cn1,$req);
                  echo "< script>alert('Modification avec succe')</ script>";
       }
       else
            echo "< script>alert('Erreur !!!!')< /script>";
    }
      if (isset($_POST['supp'])) {
        if (!empty($_POST['cne'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeC=$_POST['codeC'];
                  $nom=$_POST['nomP'];
                  $cne=$_POST['cne'];
                  $req="delete from etudiants where CNE='$cne'";
                  mysqli_query($cn1,$req);
                  echo "< script>alert('Suppression avec succe')</ script>";
       }
       else
            echo "< script>alert('Erreur !!!!')</ script>";
    }
     ?>

</pre>
</div>

</div>
<div class="col1">
<div  class="carde">
<h2> Code source matiere :</h2><br> 

<pre>

if (isset($_POST['ajou'])) {
        if (!empty($_POST['codeM']) && !empty($_POST['des'])) {
        
                  $cn=connection('gestionnotes');
                  $codeM=$_POST['codeM'];
                  $des=$_POST['des'];
                  $req="insert into matieres values('$codeM','$des')";
                  mysqli_query($cn,$req);
                  echo "< script>alert('Ajout avec succe')</ script>";
       }
       else
            echo "< script>alert('Erreur !!!!')</ script>";
    }
     if (isset($_POST['mod'])) {
        if (!empty($_POST['codeM']) && !empty($_POST['des'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeM=$_POST['codeM'];
                  $des=$_POST['des'];
                  $req="update matieres SET designation='$des' where codeMat='$codeM'";
                  mysqli_query($cn1,$req);
                  echo "< script>alert('Modification avec succe')</ script>";
       }
       else
            echo "< script>alert('Erreur !!!!')</ script>";
    }
      if (isset($_POST['supp'])) {
        if (!empty($_POST['codeM'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeM=$_POST['codeM'];
                  $des=$_POST['des'];
                  $req="delete from matieres where codeMat='$codeM'";
                  mysqli_query($cn1,$req);
                  echo "< script>alert('Suppression avec succe')</ script>";
       }
       else
            echo "< script>alert('Erreur !!!!')</ script>";
    }
     ?>

</pre>
</div>

</div>
<div class="col1">
<div  class="carde">
<h2> Code source notation :</h2><br> 

<pre>


$req="select * from matieres";
    $data=mysqli_query(connection('gestionnotes'),$req);
    while($matiere= mysqli_fetch_array($data))
    {
      echo "< tr>
               < td>".$matiere['0']."< /td>
              < td>".$matiere['1']."</ td>
            </ tr>";
    }
     ?>
    < /table>< /center>
    < ?php 
      if (isset($_POST['ajou'])) {
        if (!empty($_POST['codeM']) && !empty($_POST['cne']) && !empty($_POST['note'])) {
        
                  $cn=connection('gestionnotes');
                  $codeM=$_POST['codeM'];
                  $note=$_POST['note'];
                  $cne=$_POST['cne'];
                  $req="insert into notes values('$codeM','$cne',$note)";
                  mysqli_query($cn,$req);
                  echo "< script>alert('Ajout avec succe')</ script>";
       }
       else
            echo "< script>alert('Erreur !!!!')</ script>";
    }
     if (isset($_POST['mod'])) {
        if (!empty($_POST['codeM']) && !empty($_POST['cne']) && !empty($_POST['note'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeM=$_POST['codeM'];
                  $note=$_POST['note'];
                  $cne=$_POST['cne'];
                  $req="update notes SET note= $note where CNE='$cne'";
                  mysqli_query($cn1,$req);
                  echo "< script>alert('Modification avec succe')</ script>";
       }
       else
            echo "< script>alert('Erreur !!!!')</ script>";
    }
      if (isset($_POST['supp'])) {
        if (!empty($_POST['cne'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeM=$_POST['codeM'];
                  $note=$_POST['note'];
                  $cne=$_POST['cne'];
                  $req="delete from notes where CNE='$cne'";
                  mysqli_query($cn1,$req);
                  echo "< script>alert('Suppression avec succe')</ script>";
       }
       else
            echo "< script>alert('Erreur !!!!')</ script>";
    }

    
     ?>

</pre>
</div>

</div>
</div>
</div>


</body>
</html>
