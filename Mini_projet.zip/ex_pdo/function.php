<?php 
   function connection($bd)
  {
  	return mysqli_connect("localhost","root","",$bd);
  }
 ?>