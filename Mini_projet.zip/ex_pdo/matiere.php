<?php 
 include 'function.php';
 ?>
<html>
<head>
   <meta charset="utf-8">
  <title>Prof_Matières</title>
 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="style.css">

</head>

<body >
      <?php 
  if (isset($_POST['retour'])) {
    header('location:professeur.php');
  }
    
   ?>
              <form method="POST">
              <button class="btn btn-danger" name="retour" style="margin:10px 0px 0px 10px;">Retour</button>
              <button class="btn btn-danger" name="retour" style="margin:10px 0px 0px 10px;"> <a  href="../Mini_project/home.php">
     Accueil</a></button>
     <button class="btn btn-danger" name="retour" style="margin:10px 0px 0px 10px;"> <a  href="code.php">
     Code source</a></button>
            </form>
    <h3 align="center" style="margin-top: 60px;"><em><b>Matières</b></em></h3>
    <table align="center" style="margin-top: 50px;">
        <form action="" method="POST">    
          
          <tr><td>Code Matière:</td>
              <td><input type="text" class="form-control" name="codeM" placeholder="025"></td>
          </tr> 
          <tr>
            <TD>Désignation:</TD>
            <td><input type="text" class="form-control" name="des" placeholder="PHP"  ></td><td></td>
          </tr>
          <tr><td></td>
              <td></td>
          </tr>
          <tr ><td></td><td></td></tr>

          <tr><td><button class="btn btn-primary" name="ajou">Ajouter</button></td>
            <td><button class="btn btn-secondary" name="mod">Modifier</button></td>
            <td><button class="btn btn-danger" name="supp">Supprimer</button></td></tr>
          
        </form>
    </table>
    <?php 
      if (isset($_POST['ajou'])) {
        if (!empty($_POST['codeM']) && !empty($_POST['des'])) {
        
                  $cn=connection('gestionnotes');
                  $codeM=$_POST['codeM'];
                  $des=$_POST['des'];
                  $req="insert into matieres values('$codeM','$des')";
                  mysqli_query($cn,$req);
                  echo "<script>alert('Ajout avec succe')</script>";
       }
       else
            echo "<script>alert('Erreur !!!!')</script>";
    }
     if (isset($_POST['mod'])) {
        if (!empty($_POST['codeM']) && !empty($_POST['des'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeM=$_POST['codeM'];
                  $des=$_POST['des'];
                  $req="update matieres SET designation='$des' where codeMat='$codeM'";
                  mysqli_query($cn1,$req);
                  echo "<script>alert('Modification avec succe')</script>";
       }
       else
            echo "<script>alert('Erreur !!!!')</script>";
    }
      if (isset($_POST['supp'])) {
        if (!empty($_POST['codeM'])) {
        
                  $cn1=connection('gestionnotes');
                  $codeM=$_POST['codeM'];
                  $des=$_POST['des'];
                  $req="delete from matieres where codeMat='$codeM'";
                  mysqli_query($cn1,$req);
                  echo "<script>alert('Suppression avec succe')</script>";
       }
       else
            echo "<script>alert('Erreur !!!!')</script>";
    }
     ?>
  </body>
  </html>