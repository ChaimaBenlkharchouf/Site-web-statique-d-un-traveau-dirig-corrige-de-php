<?php 
 session_start();
 include 'function.php';
 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Imprimer </title>

    <style>
        #company {
            font-size: 25px;
            font-weight: bold;
            padding-top: 15px;
            line-height: 56px;
            height: 56px;
            width: 420px !important;
        }

        .invoice-box {
            max-width: 950px;
            margin: auto;
            padding: 30px;
            border: 1px solid #eee;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
            font-size: 16px;
            line-height: 24px;
            font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
            color: #555;
        }

        .invoice-box table {
            width: 100%;
            line-height: inherit;
            text-align: left;
        }

        .invoice-box table td {
            padding: 5px;
            vertical-align: top;
        }

        .invoice-box table tr td:nth-child(2) {
            text-align: right;
        }

        .invoice-box table tr.top table td {
            padding-bottom: 20px;
        }

        .invoice-box table tr.top table td.title {
            font-size: 45px;
            line-height: 45px;
            color: #333;
        }

        .invoice-box table tr.information table td {
            padding-bottom: 40px;
        }

        .invoice-box table tr.heading td {
            background: #eee;
            border-bottom: 1px solid #ddd;
            font-weight: bold;
        }

        .invoice-box table tr.details td {
            padding-bottom: 20px;
        }

        .invoice-box table tr.item td {
            border-bottom: 1px solid #eee;
        }

        .invoice-box table tr.item.last td {
            border-bottom: none;
        }

        .invoice-box table tr.total td:nth-child(2) {
            border-top: 2px solid #eee;
            font-weight: bold;
        }

        @media only screen and (max-width: 600px) {
            .invoice-box table tr.top table td {
                width: 100%;
                display: block;
                text-align: center;
            }

            .invoice-box table tr.information table td {
                width: 100%;
                display: block;
                text-align: center;
            }
        }

        /** RTL **/
        .rtl {
            direction: rtl;
            font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        }

        .rtl table {
            text-align: right;
        }

        .rtl table tr td:nth-child(2) {
            text-align: left;
        }

        input {
            border-left-width: 1px;
            border-right-width: 1px;
            overflow: hidden;
        }

        .span-12 {
            border-left-width: 1px;
            border-right-width: 1px;
        }

        input {
            border: 0;
            border: 1px;
            background: none;
            padding: 0;
            font-size: 15px;
            color: #222;
            font-family: "Helvetica Neue", arial, sans;
            line-height: 23px;
        }

        input, textarea {
            -webkit-appearance: none;
            -webkit-border-radius: 0;
            background: transparent;
            border: 1px;
        }

        input:focus {
            background: rgba(255, 255, 100, 0.4) !important;
            background: -webkit-gradient(linear, left top, left bottom, from(rgba(255, 255, 100, 0.5)), to(rgba(255, 255, 100, 0.1))) !important;
            color: #000;
            text-shadow: #fff 1px 1px;
            -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.1);
        }

        textarea.notes {
            padding: 20px 70px 0px 70px;
            font-family: "Helvetica Neue", arial, sans;
            font-size: 14px;
            background: none;
            line-height: 21px;
            border: 0;
            resize: none;
            font-size: 15px;
            margin: 10px auto 0px auto;
            width: 250px;
            height: 100px;
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!--    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.8.1/html2pdf.bundle.min.js"></script>-->
    <script src="https://rawgit.com/eKoopmans/html2pdf/master/dist/html2pdf.bundle.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <script>
        function generatePDF() {
            // Choose the element that our invoice is rendered in.
            const element = document.getElementById("invoice");
            // Choose the element and save the PDF for our user.
            var pdf;
            var pdfout;
            var Narvarande = "Johnny";
            var filnamn = "123456";
            var Lagenhetsadress = "BB1234 43";
            html2pdf().from(element).output('datauri').then(function (pdfout) {

//  console.log(btoa(pdf));;

                $.ajax({
                    method: "POST",
                    url: "save.php",
                    data: {
                        data: pdfout,
                        besiktare: Narvarande,
                        namn: filnamn,
                        adress: Lagenhetsadress,
                    },
                }).done(function (data) {
                    console.log("Return från skickapdf: ");
                    console.log(data);
                });

            }).saveAs();
        }
    </script>
</head>

<body><br>
    
<div class="invoice-box" id="invoice">
     <h3 align="center" style="margin-top: 60px;"><em><b>ROYALE MAROC</b></em></h3>

     <input value="Français /ا لعربية" " style="margin-left: 750px;"><br/>
     
     <input id="company" class="span-12 ll" value="Bulletin">
     
     <input value="Le: <?php echo date('Y-m-d'); ?>" style="margin-left: 550px;"><br/>
     
     <input value="CNE:  <?php echo$_SESSION['cnee']; ?> " style="margin-left: 550px;"><br/><br>
     
     <input value="Nom Et Prénom:  <?php echo$_SESSION['nom'];?>" style="margin-left: 550px;"><br/>
     
    <input value="Filière:  <?php echo$_SESSION['filiere'];?>" style="margin-left: 550px;"><br><br>
    
    <table cellpadding="0" cellspacin="0">
        <tr class="top">
                <?php 

                     $cne=$_SESSION['cnee'];
                     $nom=$_SESSION['nom'];
                     $filiere=$_SESSION['filiere'];
                     
                     $cn=connection('gestionnotes');
                     
                     $query=  "select designation , note from matieres m , notes n , etudiants e , classes c  
                                      where n.codeMat=m.codeMat
                                      and e.codeClasse=c.codeClasse
                                      and n.CNE='$cne'
                                      and e.nom='$nom'
                                      and c.filiere='$filiere'";

                     
                        ?>                                 
                                                 
                <tr class="bg-light">
                        <th> Matière</th><th>Note</th><th>Résultat</th>
                 </tr>
                 <?php
                         $data=mysqli_query($cn,$query);
           while ($donne=mysqli_fetch_array($data)) {
             echo "<tr>
                     <th>".$donne[0]."</th>
                     <th>".$donne[1]."</th>";

                     if ($donne[1]>=12) 
                       echo "<td>V</td>";
                                      
                   
                   elseif($donne[1]>=6 && $donne[1]<12) 
                     echo "<td>R</td>";
                   
                   else
                    echo "<td>NV</td>";
                  echo"</tr>";
                  
            }
            echo "<tr class=bg-light ><td><b>Moyenne</b></td>";
            $re="select avg(note) from notes where CNE='$cne'";
            $data=mysqli_query($cn,$re);
            if ($donnee=mysqli_fetch_array($data)) {
              echo "<th colspan=2>$donnee[0]</th></tr>";}
           
                     
                    
               
            ?>
    </table>
<br><br>
    
    <textarea class="notes growfield" id="textone" cols="95" rows="1"
              style="resize: none; overflow: hidden; height: 182px;">Signiature</textarea>

</div><br>
<div align="center"> 
                            <button  type="submit" class="btn btn-success" onclick="window.print();" classe="btn btn primary" id="print-btn" >
                                          <span href="BSD.php"> 
                                          <b>Imprimer </b>
                                          </span> 
                            </button>
                                     </div> <br>


</body>
</html>