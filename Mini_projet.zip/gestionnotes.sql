-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 24 déc. 2021 à 00:59
-- Version du serveur :  10.4.17-MariaDB
-- Version de PHP : 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestionnotes`
--

-- --------------------------------------------------------

--
-- Structure de la table `classes`
--

CREATE TABLE `classes` (
  `codeClasse` varchar(20) NOT NULL,
  `filiere` varchar(50) NOT NULL,
  `num` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `classes`
--

INSERT INTO `classes` (`codeClasse`, `filiere`, `num`) VALUES
('b120', 'infoo', 1),
('b125', 'genie info', 2);

-- --------------------------------------------------------

--
-- Structure de la table `etudiants`
--

CREATE TABLE `etudiants` (
  `CNE` varchar(20) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `codeClasse` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `etudiants`
--

INSERT INTO `etudiants` (`CNE`, `nom`, `codeClasse`) VALUES
('B135065783', 'Hamza', 'b120'),
('B135082345', 'azza mohamed', 'b120'),
('B138026570', 'Redouan', 'b125');

-- --------------------------------------------------------

--
-- Structure de la table `matieres`
--

CREATE TABLE `matieres` (
  `codeMat` varchar(20) NOT NULL,
  `designation` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `matieres`
--

INSERT INTO `matieres` (`codeMat`, `designation`) VALUES
('1', 'php'),
('2', 'JAVA POO'),
('3', 'Réseaux'),
('4', 'Sport'),
('6', 'Gestion de projets');

-- --------------------------------------------------------

--
-- Structure de la table `notes`
--

CREATE TABLE `notes` (
  `codeMat` varchar(20) NOT NULL,
  `CNE` varchar(20) NOT NULL,
  `note` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `notes`
--

INSERT INTO `notes` (`codeMat`, `CNE`, `note`) VALUES
('1', 'B135082345', 14.2),
('2', 'B135082345', 19),
('3', 'B138026570', 16.5),
('4', 'B138026570', 19),
('6', 'B138026570', 18),
('1', 'B138026570', 17),
('2', 'B138026570', 11.5),
('1', 'B135065783', 14.2),
('2', 'B135065783', 3),
('4', 'B135065783', 19);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`codeClasse`);

--
-- Index pour la table `etudiants`
--
ALTER TABLE `etudiants`
  ADD PRIMARY KEY (`CNE`),
  ADD KEY `codeClasse` (`codeClasse`);

--
-- Index pour la table `matieres`
--
ALTER TABLE `matieres`
  ADD PRIMARY KEY (`codeMat`);

--
-- Index pour la table `notes`
--
ALTER TABLE `notes`
  ADD KEY `codeMat` (`codeMat`),
  ADD KEY `CNE` (`CNE`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `etudiants`
--
ALTER TABLE `etudiants`
  ADD CONSTRAINT `codeClasse` FOREIGN KEY (`codeClasse`) REFERENCES `classes` (`codeClasse`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `notes`
--
ALTER TABLE `notes`
  ADD CONSTRAINT `CNE` FOREIGN KEY (`CNE`) REFERENCES `etudiants` (`CNE`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `codeMat` FOREIGN KEY (`codeMat`) REFERENCES `matieres` (`codeMat`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
