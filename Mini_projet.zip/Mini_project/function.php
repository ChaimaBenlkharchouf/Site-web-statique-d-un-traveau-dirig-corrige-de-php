<?php
function Rpetition($txt,$a)
		 {	   
		 	    
				$nbr=0;
				$tab = str_split($txt);
                $indice=$tab[$a];
                for($i=$a;$i<count($tab);$i++){
                	if($tab[$i]!=$indice) {
                		break;			}

                		$nbr++;

												}
                
			 return $nbr;
									
								}

function fullnames($fn,$ln){
		if (isset($_POST['ok'])) {
			$fn=$_POST['fname'];
			$ln=$_POST['lname'];
			$fullname=$fn.' '.$ln;
			return $fullname;
		}
		}

function Remplacer($txt,$x)
		{
		
			
				$y=$_POST['y'];
				$arr = array($txt);
				$table=str_replace($x,$y,$arr);
				foreach($table as $tables ){
					return $tables;
				}
               
								
					}
function CodageRLE($txt)
    {
               $tab=str_split($txt);
                $n=0;
                $var="";
                do{
                $rep=Rpetition($txt,$n);
                $var=$var.$rep.$tab[$n];
                $n=$n+$rep;

                }while($n<count($tab));
                return $var;
            }
function Entier($txt,$a)
            {
            	$tab = str_split($txt);
                 $contenu=$tab[$a];
                 $var="";
                 $nbr=0;
                 if (is_numeric($contenu)) {
                     for($i=$a;$i<count($tab);$i++){
                	    if(is_numeric($tab[$i])){ 
                	    	 $nbr++;
                	    	$var=$var.$tab[$i]; }		
                	    else{
                	    	$table=array($var,$nbr);
                		    return $table; 
                		  }	
                		
									}
									}
				 else{
				 	     $table=array(0,0);

							return $table;
							
								}
					  	    	$table=array($var,$nbr);
								return $table;
}
function DecodageRLE($txt){
   $n=0;
   $tab=str_split($txt);
   $chaine="";
  $valeur=Entier($txt,$n);
  $n=$n+$valeur[1];
   do{
        
    for ($i=0; $i<$valeur[0] ; $i++) { 
        $chaine=$chaine.$tab[$n];
    }
    $n=$n+$valeur[1]+1;
   }while($n<count($tab));
    
    return $chaine;
}
?>