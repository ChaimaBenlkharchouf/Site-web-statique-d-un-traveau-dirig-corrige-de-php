<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 1200px;
    align-items: center;
}
.col1{
    flex-basis: 100%;
}
.carde{
    width: 90%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 90%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}

    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="home.php">L'accueil </a></li>
                    <li><a href="TP.php">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="./img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2>
<center>
   <div >  
   <pre>
   
   < div class="col1"><br>
< div  class="carde"><br>
< h2> Resultat :</ h2><br> 
< form  action= " < ? php echo $ _SERVER["PHP_SELF"] ? >" method="post"  ><br>
</ br> < center>
< fieldset><br>
  < legend> S'il vous plais remplire tous les champs: </ legend><br>
< label> Nom :</ label><br>
< input type="text" name="nom" placeholder=" Tapez votre nom :"> </ br><br>
< label> Prénom :</ label><br>
< input type="text" name="prenom" placeholder=" Tapez votre prénom:">
</ br></ br></br>
< input type="submit" name="ok"  values=" Valider "><br>
</ br></ br> </ fieldset>
</ center> </ form>
< ? php <br>

functio n addNom-(){<br>
    $ name1 =$ _POST['nom'];<br>
    $ name2 =$ _POST['prenom'];<br>
    $ _POST['res']= $ name1." ".$ name2;<br>
    return  $ _POST['res'];<br>
  }
e cho '< br>';<br>
e cho '< br>';<br>
e cho '< fieldset>';<br>
e cho' < legend> Resultat final: </ legend>';<br>
e cho '< center>';<br>
e cho '< h1 style=" color: brown;<br>
  font-size: larger;<br>
  font-family: "Times New Roman", Times, serif;<br>
  font-style: italic;">'; <br>
e cho '< span style="background-color: yellow;" center>';<br>
$ message= addNom- (); ?> <br>
< script> <br>
alert('< ? php ech o $ message;?  >')
</ script> <br>
< ? php<br>
ech o addNom();     ech o '</ span>';     ech o '< /h1>';  
ech o '</ fieldset>';<br>

?><br>
</pre>
</div>
</center>
</div>
</div>
<div class="col1">
<div  class="carde">
<h2> Resultat :</h2><br> 
<form  action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post"  >
</br>
</br>
<center>
<fieldset>
  <legend> S'il vous plais remplire tous les champs: </legend>
<label> Nom :</label>
<input type="text" name="nom" placeholder=" Tapez votre nom :">
</br><br>
<label> Prénom :</label>
<input type="text" name="prenom" placeholder=" Tapez votre prénom:">
</br></br></br>
<input type="submit" name="ok"  values=" Valider ">
</br></br></br>
</fieldset>
</center>
</form>
<?php

function addNom(){
    $name1 =$_POST['nom'];
    $name2 =$_POST['prenom'];
    $_POST['res']= $name1." ".$name2;
    return  $_POST['res'];
  }
echo '<br>';
echo '<br>';
echo '<fieldset>';
echo' <legend> Resultat final: </legend>';
echo '<center>';
echo '<h1 style=" color: brown;
  font-size: larger;
  font-family: "Times New Roman", Times, serif;
  font-style: italic;">'; 
echo '<span style="background-color: yellow;" center>';
echo addNom();
echo '</span>';
echo '</h1>';
echo '</fieldset>';
$message=addNom(); 
?>
<script>
alert('<?php echo $message;?>')
</script>


     
</div>

</div>

</div>


</body>
</html>
