<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 88%;
    align-items: center;
}
.col1{
    flex-basis: 80%;
}
.carde{
    width: 80%;
    height: 80%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 80%;
    height: 80%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}

    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="home.php">L'accueil </a></li>
                    <li><a href="TP.php">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="./img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2><br><br><br><br>
<center>
Considérons les variables $Licences = 3 ; $Masters = 2 ;
Afficher, à l’aide d’une seule instruction PHP, la phrase suivante :<br>
<mark>J’ai 3 Licences et 2 Masters, j’ai donc 5 formations.</mark><br>
Les nombres 3, 2 et 5 dépendent des valeurs des variables données précédemment. Le faire
une fois en utilisant uniquement les apostrophes et une fois en utilisant uniquement lesguillemets.
   <div style="background-color: grey;">  
   <pre> 
<br>< ? php <br>
   
   $Licences =3;<br>
   $Master= 2;
   <br>
   echo "< br/>";<br>
   echo "J'ai ".$Licences." Licence et ". $Master." Masters, j'ai donc ".$Licences+$Master ." farmations.";
 <br>  ?> </div></pre>
</center>
</div>
</div>
<div class="col1">

<div  class="carde">
<h2> Resultat :</h2><br><br><br><br>
    <center> <?php
   
$Licences =3;
$Master= 2;
echo "<br/>";
echo "J'ai ".$Licences." Licence et ". $Master." Masters, j'ai donc ".$Licences+$Master ." farmations.";

?>
</center>
</div>

</div>

</div>
</body>
</html>
