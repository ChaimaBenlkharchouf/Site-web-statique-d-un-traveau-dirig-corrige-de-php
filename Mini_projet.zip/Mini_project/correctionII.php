<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 100%;
    align-items: center;
}
.col1{
    flex-basis: 100%;
}
.carde{
    width: 90%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 90%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}

    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="home.php">L'accueil </a></li>
                    <li><a href="TP.php">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="./img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2>
<center>
   <div >  
< ? php <br>

echo "< br/>";echo "< br/>";<br>
$Ville='Tanger';<br>
$TempVille= 23;<br>

$TabColor=array('Rouge_foncé'=>array(50,33,'#8B0000'),<br>
'Rouge'=>array(28,32,'#FF0000'),<br>
'Ecarlte'=>array(27,22,'rgb(255,117,0)'),<br>
'Orange'=>array(21,17,'#FF4500'),<br>
'Jaune'=>array(16,11,'#FFFF00'),<br>
'Vert riche'=>array(10,5,'rgb(255,0,0)'),<br>
'Vert'=>array(4,0,'#008000'),<br>
'Bleu ciel'=>array(-1,-6,'#87CEEB'),<br>
'Bleu'=>array(-6,-11,'#0000FF'),<br>
'Violet'=>array(-12,-17,'#800080'),<br>
'Violet rose'=>array(-18,-22,'rgb(255,0,0)'),<br>
'Magenta'=>array(-23,-50,'#FF00FF'));  echo '< center>';<br>
echo '< table border=1  width=500px  height=500px> ';<br>
echo '< tr>';<br>
echo '< th> Couleur < /th> ';<br>
echo '< th> température  < /th> ';<br>
echo '< th>ville < /th> ' ;echo '< /tr>';
<br>

foreach($TabColor as $key => $Val)<br>
{echo '< tr>';<br>

   
    echo "< td style='background-color : ".$Val[2]."'>" ;<br>
   
   echo "< td>Entre ".$Val[0]." et ".$Val[1];<br>
   echo '< /td>';<br>
   if($TempVille <= $Val[0] and $TempVille > $Val[1]){<br>

    echo "< td style='color:". $Val[2] ."'> $Ville < /td>";<br>

}else{    echo "< td> < /td>";<br>}
echo '< /tr>';}<br>


echo '< /table >';  echo "</ center>";<br>
  
<br>  ?> </div>
</center>
</div>
</div>
<div class="col1">

<div  class="carde">
<h2> Resultat :</h2><br>
    <center> <?php
   

   echo "<br/>";echo "<br/>";
   $Ville='Tanger';
   $TempVille= 23;
   
   $TabColor=array('Rouge_foncé'=>array(50,33,'#8B0000'),
   'Rouge'=>array(28,32,'#FF0000'),
   'Ecarlte'=>array(27,22,'rgb(255,117,0)'),
   'Orange'=>array(21,17,'#FF4500'),
   'Jaune'=>array(16,11,'#FFFF00'),
   'Vert riche'=>array(10,5,'rgb(255,0,0)'),
   'Vert'=>array(4,0,'#008000'),
   'Bleu ciel'=>array(-1,-6,'#87CEEB'),
   'Bleu'=>array(-6,-11,'#0000FF'),
   'Violet'=>array(-12,-17,'#800080'),
   'Violet rose'=>array(-18,-22,'rgb(255,0,0)'),
   'Magenta'=>array(-23,-50,'#FF00FF'));
   
   echo '<center>';
   echo '<table border=1  width=500px  height=500px> ';
   echo '<tr>';
   echo '<th> Couleur </th> ';
   echo '<th> température  </th> ';
   echo '<th>ville </th> ' ;
   echo '</tr>';
   
   
   foreach($TabColor as $key => $Val)
   {echo '<tr>';
   
      
       echo "<td style='background-color : ".$Val[2]."'>" ;
      
      echo "<td>Entre ".$Val[0]." et ".$Val[1];
      echo '</td>';
      if($TempVille <= $Val[0] and $TempVille > $Val[1]){
   
       echo "<td style='color:". $Val[2] ."'> $Ville </td>";
   
   }else{ 
       echo "<td> </td>";
       }
   
   echo '</tr>';
   
   }
   
   
   echo '</table >';
   
   echo "</center>";
?>
</center>
</div>

</div>

</div>
</body>
</html>
