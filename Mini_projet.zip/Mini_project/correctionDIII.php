<?php
          include "function.php";
 ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 1200px;
    align-items: center;
}
.col1{
    flex-basis: 100%;
}
.carde{
    width: 90%;
    height: 80%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 90%;
    height: 80%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}

    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="home.php">L'accueil </a></li>
                    <li><a href="TP.php">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="./img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2>
<br>
<center>
   <div >  
   <pre>
   
< table align="center"><br>
	< form method="POST"><br>
		< tr>< td>TXT:< /td> < td>< input type="text" name="txt"></ td>< /tr><br>
		< tr>< td>i:  < /td>< td>< input type="text" name="i">< /td>< /tr><br>
		 < tr>< td>< /td> < td> < input type="submit" name="ok">< /td>< /tr><br>

      < ?php  <br>   
            if(isset($_POST['ok'])){
				$txt=$_POST['txt'];
				$a=$_POST['i'];<br>
				 
			echo"< tr >< td>RES: < /td>< td>< input type=text name=res value=".Entier($txt,$a)[0].">< /td><br>
			         < td>Nbr: < /td>< td>< input type=text name=nbr value=".Entier($txt,$a)[1].">< /td>< /tr>";	
									}<br>
                                    
function Entier($txt,$a)
{<br>
    $tab = str_split($txt);<br>
     $contenu=$tab[$a];<br>
     $var="";
     $nbr=0;<br>
     if (is_numeric($contenu)) {<br>
         for($i=$a;$i< count($tab);$i++){<br>
            if(is_numeric($tab[$i])){ <br>
                 $nbr++;
                $var=$var.$tab[$i]; }<br>		
            else{
                $table=array($var,$nbr);
                return $table; 
              }	
            
                        }
                        }<br>
     else{
              $table=array(0,0);

                return $table;<br>
                
                    }<br>
                      $table=array($var,$nbr);
                    return $table;
}

      ?><br>

	< /form>
< /table>


<br>
</pre>
</div>
</center>
</div>
</div>
<div class="col1">
<div  class="carde">
<h2> Resultat :</h2><br> 


<table align="center">
	<form method="POST">
		<tr><td>TXT:</td> <td><input type="text" name="txt"></td></tr>
		<tr><td>i:  </td><td><input type="text" name="i"></td></tr>
		 <tr><td></td> <td> <input type="submit" name="ok"></td></tr>

      <?php     

                
                if(isset($_POST['ok'])){
				$txt=$_POST['txt'];
				$a=$_POST['i'];
				 
			echo"<tr><td>RES: </td><td><input type=text name=res value=".Entier($txt,$a)[0]."></td>
			         <td>Nbr: </td><td><input type=text name=nbr value=".Entier($txt,$a)[1]."></td></tr>";	
									}

      ?>

	</form>
</table>

</div>

</div>

</div>


</body>
</html>
