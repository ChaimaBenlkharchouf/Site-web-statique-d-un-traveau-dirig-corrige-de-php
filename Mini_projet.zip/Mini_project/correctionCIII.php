<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 1200px%;
    align-items: center;
}
.col1{
    flex-basis: 100%;
}
.carde{
    width: 90%;
    height: 80%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 90%;
    height: 80%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}

    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="home.php">L'accueil </a></li>
                    <li><a href="TP.php">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="./img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2>
<br><br>
<center>
   <div >  
   <pre>
   < form  action="< ?php echo $_SERVER["PHP_SELF"] ?>" method="post"  >

</ br>
< /br>
< center></br>
< fieldset>
    < legend> S'il vous plais remplire tous les champs: < /legend></br>

< label> Entrez un ensemble des lettres :< /label></br>
< input type="text" name="txt" placeholder=" Tapez une suite des lettres:">
< /br>< br></br>
< label> Charcher sur un indice :< /label></br>
< input type="number" name="a" placeholder=" Tapez l'indice :">


< /br > < /br></br>

< input type="submit" name="ok"  values="Valider "></br>

< /fieldset>
< /center>
< /form></br>

< ?php</br>

if(isset($_POST['ok'])){</br>
  $message=null; 
  $txt=$_POST['txt'];
  $a=$_POST['a'];</br>
function RPT($txt,$a)
{	   </br>
            
           $nbr=0;
           $tab = str_split($txt);
           $indice=$tab[$a];
           for($i=$a;$i< count($tab);$i++){</br>
               if($tab[$i]!=$indice) {
                   break;			}

                   $nbr++;

                                           }</br>
           
        return $nbr;</br>
                               
                           }

}

<br> </pre>

</div>
</center>
</div>
</div>
<div class="col1">
<div  class="carde">
<h2> Resultat :</h2><br> 

<form  action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post"  >

</br>
</br>
<center>
<fieldset>
    <legend> S'il vous plais remplire tous les champs: </legend>

<label> Entrez un ensemble des lettres :</label>
<input type="text" name="txt" placeholder=" Tapez une suite des lettres:">
</br><br>
<label> Charcher sur un indice :</label>
<input type="number" name="a" placeholder=" Tapez l'indice :">


</br></br></br>

<input type="submit" name="ok"  values="Valider ">

</fieldset>
</center>
</form>

<?php

if(isset($_POST['ok'])){
  $message=null; 
  $txt=$_POST['txt'];
  $a=$_POST['a'];
function RPT($txt,$a)
{	   
            
           $nbr=0;
           $tab = str_split($txt);
           $indice=$tab[$a];
           for($i=$a;$i<count($tab);$i++){
               if($tab[$i]!=$indice) {
                   break;			}

                   $nbr++;

                                           }
           
        return $nbr;
                               
                           }

}


echo '<br>';
echo '<br>';
echo '<fieldset>';
   echo' <legend> Resultat final: </legend>';

 echo '<center>';

echo '<h1 style=" color: brown;
  font-size: larger;
  font-family: "Times New Roman", Times, serif;
  font-style: italic;">'; 
echo '<span style="background-color: yellow;" center>';
$message=RPT($txt,$a); 
?>

<script>
alert('<?php echo $message;?>')
</script>
<?php

echo RPT($txt,$a);

echo '</span>';
echo '</h1>';
echo '</fieldset>';
//----------------------EXERCICE_C-------------

?>


     
</div>

</div>

</div>


</body>
</html>
