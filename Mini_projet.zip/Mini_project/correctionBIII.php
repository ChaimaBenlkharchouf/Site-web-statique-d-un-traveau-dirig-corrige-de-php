<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 1300px;
    align-items: center;
}
.col1{
    flex-basis: 100%;
}
.carde{
    width: 90%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 90%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}

    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="home.php">L'accueil </a></li>
                    <li><a href="TP.php">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="./img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2>
<center>
   <div >  

   <form  action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post"  >

</br>
</br>
<center> <pre>
< fieldset></br>
    <  legend> S'il vous plais remplire tous les champs: < /legend></br>

< label> Votre phrase :< /label></br>
< input type="text" name="A" placeholder=" Tapez  une phrase:">
< /br></br>
 < /fieldset></br>
< fieldset>< legend> Phase pour changer un lettre:< /legend></br>
< label> Votre nouvau lettre :< /label></br>
< input type="text" name="X" placeholder=" Tapez le nouvau lettre que vous voulez changer :"></br>


 < label> Votre ancien lettre :< /label></br>
< input type="text" name="Y" placeholder=" Tapez l'ancien lettre  :">
< /br></ br></br>

< input type="submit" name="ok"  values=" Valider "></br>

< /fieldset>
< /center>
< /form></br>


< ?php</br>
    function rmp(){</br>
for($i=0;$i< strlen($_POST['A']);$i++){</br>
    $afffiche= str_replace($_POST['Y'],$_POST['X'],$_POST['A']);</br>
  
    return $afffiche;
} }</br>
echo '< br>';
echo '< br>';
echo ' < br>';
echo '< br>';</br>
echo '< fieldset>';</br>
   echo' < legend> Resultat final: < /legend>';</br>

 echo '< center>';</br>

echo '< h1 style=" color: brown;
  font-size: larger;
  font-family: "Times New Roman", Times, serif;
  font-style: italic;">'; </br>
echo '< span style="background-color: yellow;" center>';</br>
$msg=rmp();
echo rmp();</br>
echo '</ span>';
echo '</ h1>';
echo '</ fieldset>';</br>

?></br>

< script>
alert('< ?php echo $msg;?>')
</ script>
< br></br> </pre>
</div>
</center>
</div>
</div>
<div class="col1">
<div  class="carde">
<h2> Resultat :</h2><br> 

    

<form  action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post"  >

</br>
</br>
<center>
<fieldset>
    <legend> S'il vous plais remplire tous les champs: </legend>

<label> Votre phrase :</label>
<input type="text" name="A" placeholder=" Tapez  une phrase:">
</br>
</fieldset>
<fieldset><legend> Phase pour changer un lettre:</legend>
<label> Votre nouvau lettre :</label>
<input type="text" name="X" placeholder=" Tapez le nouvau lettre que vous voulez changer :">


 <label> Votre ancien lettre :</label>
<input type="text" name="Y" placeholder=" Tapez l'ancien lettre  :">
</br></br></br>

<input type="submit" name="ok"  values=" Valider ">

</fieldset>
</center>
</form>


<?php
    function rmp(){
for($i=0;$i<strlen($_POST['A']);$i++){
    $afffiche= str_replace($_POST['Y'],$_POST['X'],$_POST['A']);
  
    return $afffiche;
} }
echo '<br>';
echo '<br>';
echo '<br>';
echo '<br>';
echo '<fieldset>';
   echo' <legend> Resultat final: </legend>';

 echo '<center>';

echo '<h1 style=" color: brown;
  font-size: larger;
  font-family: "Times New Roman", Times, serif;
  font-style: italic;">'; 
echo '<span style="background-color: yellow;" center>';
$msg=rmp();
echo rmp();
echo '</span>';
echo '</h1>';
echo '</fieldset>';

?>

<script>
alert('<?php echo $msg;?>')
</script>

     
</div>

</div>

</div>


</body>
</html>
