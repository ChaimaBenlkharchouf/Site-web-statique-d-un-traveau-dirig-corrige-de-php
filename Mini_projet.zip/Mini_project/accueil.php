<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Style1.css">
    <title>Document</title>
  
</head>
<body>
    <div class="header">
        <div class="navar">
            <div class="logo">
                <a href="#"><img src="img/logo.jpg" alt=""  width="50" height="50"></a>
            </div>
            <div class="menu" class="login-btn" >
               <ul>
                    <li>Accueil</li>
                    <li>Traveau Pratique</li>
                    <li>Cours PHP </li>
                   <li>Documentaion</li>
                </ul>
            </div>
            <div class="login-btn">
            Documentaion
            </div>
        </div>
    </div>



</body>
</html>