<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="../Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 100%;
    align-items: center;
}
.col1{
    flex-basis: 100%;
}
.carde{
    width: 90%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 90%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}
    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="../img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="../home.php">L'accueil </a></li>
                    <li><a href="../TP.php">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="../img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2>



<mark>// Formulaire avec html: <br>      </mark>
< form action="< ?php echo $_SERVER["PHP_SELF"] ?>" method ="post"><br>
    < fieldset><br>
< legend>Le nombre d'occurence question ( f && h ) :< /legend><br>
< label> Nom de fichier:< /label><br>

< input type="text" name="fiche4" >< br><br>

< label >  Contenu: < /label><br>
< textarea name="contenu4" id="" cols="30" rows="10" > < /textarea>< br><br>

< input type="text" name="char" >< br><br>
< br>< br>
< input type="submit"  name="oc"  value="Occurences"><br>
< /center>
< /fieldset>
< /form><br>
<mark>// Code PHP Fonction  monFichier2:<br>  </mark>

        < ?php <br>
   

 
function Calculer2()
{<br>
    if ( isset($_POST['fiche4']) && isset($_POST['contenu4'])) {<br>

        $fich4 =$_POST['fiche4'];
        $contenu4 =$_POST['contenu4'];
        $char =$_POST['char'];<br>

    $f=fopen("$fich4.txt", "w+") or die("error"); 
       file_put_contents("$fich4.txt",$contenu4); <br>
       if (!$f) 

    die('imppossible');<br>
    
    if(!fclose($f))
     die("Fermeture de fichier est echoue!!");<br>
     
   if(! empty($char))<br>


echo '<b>"' . $contenu4 . '"</b> contient <b>' . substr_count($contenu4, $char) . '</b> fois le :  <b>' . $char . '</b>< br>';



}}<br>

echo Calculer2();
?><br>

</div>
</div>
<div class="col1">

<div  class="carde">
<h2> Resultat :</h2><br><br><br><br>
    <center> 
    <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method ="post">
    

<fieldset>
<legend>Stocker le nombre d'occurence dans fichier question (g) :</legend>
<label> Nom de fichier:</label>

<input type="text" name="ficheg" >

<label >  Contenu: </label>
<textarea name="contenug" id="" cols="30" rows="10" > </textarea>


<br><br>
<input type="submit"  name="ocg"  value="Valider">
<input type="submit"  name="inv"  value="Inverser">
</center>
</fieldset>
</form>
        
        <?php
   

 
   function Calculer3(){

    if ( isset($_POST['ficheg']) ) {

        $fch =$_POST['ficheg'];
        $cntn=$_POST['contenug'];


    $f=fopen("$fch.txt", "w+") ;
    $fileLines=file("$fch.txt");
  
   file_put_contents("$fch.txt",$cntn);
   if ( isset($_POST['ocg']) ){
    $tab1= array("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z");
   $tot1 = 0;
 
   foreach($tab1 as $v){
   $tot1 += substr_count($cntn, $v);
    }
  $letr=  $tot1.' Lettre ' ;
   echo $letr; // Affiche : nbr voyelles
echo "<br/>";

$tab2=array(0,1,2,3,4,5,6,7,8,9);
  $tot2 = 0;
foreach($tab2 as $v1){
    $tot2 += substr_count($cntn, $v1);
     }
     $chifr = $tot2.' Chiffre ';
echo $chifr;
echo "<br/>";

$tot3 = substr_count($cntn, "\n") + 1 .' Ligne';

echo $tot3;
$res=fopen("Resultat.txt", "w+") ;
fwrite($res , $letr ." // ");
fwrite($res , $chifr ." // ");
fwrite($res , $tot3);
    }
  if (!$f) 
    die('imppossible');
    
    if(!fclose($f))
     die("Fermeture de fichier est echoue!!");

     //inverse function 
     function inverserFichier($cntn){
        if( isset($_POST['inv']))  {
        
            $fichCopy =fopen("FichCopy.txt", "w+") ;
       
       $reversed = "";
       $tmp = "";
       for($i = 0; $i < strlen($cntn); $i++) {
       if($cntn[$i] == " ") {
       $reversed .= $tmp . " ";
       $tmp = "";
       continue;
       }
       $tmp = $cntn[$i] . $tmp;    
       }
       $reversed .= $tmp;
        fwrite($fichCopy, $reversed);
        } 
       
       
         }
         inverserFichier($cntn);
       }     
       
       
       }
       echo Calculer3();
?>
</center>
</div>

</div>

</div>
</body>
</html>
