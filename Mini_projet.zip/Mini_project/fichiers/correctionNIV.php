<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="../Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 100%;
    align-items: center;
}
.col1{
    flex-basis: 100%;
}
.carde{
    width: 95%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 95%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}
    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="../img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="../home.php">L'accueil </a></li>
                    <li><a href="../TP.php">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="../img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2>

    <mark>// Code PHP Fonction  monFichier2:<br>  </mark>
<pre>
    < ?php 
  
function chargerFichier2(){
    $file="info.txt";
    $open = fopen($file,"r+");
    $read=fread($open,filesize($file));
    $tab=explode("\t",$read);
    $total=array();
    for ($i=0; $i < count($tab) ; $i++) { 
    if(intval($tab[$i])!=0 || $tab[$i]='0'){
    $total+=[$tab[$i]=>array($tab[$i+1],$tab[$i+2])];
    }
    }
    return $total;
    }
    function distrubuerVille()
    {
    $table=chargerFichier2();
    foreach($table as $key=>$val)
    {
    $valeur=strtolower($val[1]);
    $nom_file="Ville/$valeur.txt";
    if(file_exists($nom_file))
    {
    $open = fopen($nom_file, "a+");
    $read =fread($open,filesize($nom_file));
    $tab=explode("\t",$read);
    if(in_array($key,$tab)){ 
    break;
    }
    else{ 
    $contenu="$key\t\t$val[0]\t\t$val[1]";
    fwrite($open,$contenu);
    }
    }
    else{
    $open = fopen('info.txt', "a+");
    $contenu="$key\t\t$val[0]\t\t$val[1]";
    fwrite($open,$contenu);
    }
    }
    }
  
    ?>
    <pre>




        <br>

    

<br>

</div>
</div>
<div class="col1">

<div  class="carde">
<h2> Resultat :</h2><br><br><br><br>
    <center> 
    <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method ="post">
    

<fieldset>
<legend>Fichier  (M) :</legend>
<table>
    <tr>
        <td><label for="">ville a rechercher :</label></td>
        <td><input type="text" name="filename" id="" value="<?php if(isset($_POST['filename'])) echo $_POST['filename']; ?>" ></td>
        <td><input type="submit" value="Chercher sur yn ville" name="send"></td>
    </tr>
    </table>
    <table>
        <tr>
            <td><?php 
        if(isset($_POST['send'])){
            distrubuerVille($_POST['filename']); 
        }  ?></td>
        </tr>
    </table>
</fieldset>
</form>
<?php 



function chargerFichier2(){
    $file="info.txt";
    $open = fopen($file,"r+");
    $read=fread($open,filesize($file));
    $tab=explode("\t",$read);
    $total=array();
    for ($i=0; $i < count($tab) ; $i++) { 
    if(intval($tab[$i])!=0 || $tab[$i]='0'){
    $total+=[$tab[$i]=>array($tab[$i+1],$tab[$i+2])];
    }
    }
    return $total;
    }
    function distrubuerVille()
    {
    $table=chargerFichier2();
    foreach($table as $key=>$val)
    {
    $valeur=strtolower($val[1]);
    $nom_file="Ville/$valeur.txt";
    if(file_exists($nom_file))
    {
    $open = fopen($nom_file, "a+");
    $read =fread($open,filesize($nom_file));
    $tab=explode("\t",$read);
    if(in_array($key,$tab)){ 
    break;
    }
    else{ 
    $contenu="$key\t\t$val[0]\t\t$val[1]";
    fwrite($open,$contenu);
    }
    }
    else{
    $open = fopen('info.txt', "a+");
    $contenu="$key\t\t$val[0]\t\t$val[1]";
    fwrite($open,$contenu);
    }
    }
    }
 


?>
</center>
</div>

</div>

</div>
</body>
</html>
