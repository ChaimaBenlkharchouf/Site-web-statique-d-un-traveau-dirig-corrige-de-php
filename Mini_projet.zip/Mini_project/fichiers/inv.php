<?php 
function inverserFichier($n,$c){
    $str="";
    $myfile = fopen("$n", "r") or die("Unable to open file!");
    while(!feof($myfile)) {
        $str.=fgets($myfile);
      }
      $str = preg_replace( "/\r|\n/", "", $str);
      $my_array = explode(' ', $str);
    //   echo $str."<br>";
    //   print_r($my_array);
    //   $st=implode(" ",$my_array);
    //   $d=explode(" ", $st);
    //    print_r($my_array);
       $re = array_reverse($my_array);
    //    echo "<br>";
    //    print_r($re);
       file_put_contents("$c", implode(" ",$re)); 
    return $c; 
    fclose($myfile);   
}
function inverserFichier1($n,$c1){
    $c=inverserFichier($n,$c1);
    $str="";
    $myfile = fopen("$c", "r") or die("Unable to open file!");
    while(!feof($myfile)) {
        $str.=fgets($myfile);
      }
       file_put_contents("$c", strrev($str)); 
       echo strrev($str);
    fclose($myfile);   
}
// readFichier("b.txt");
//  readFichier1($n);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>TD 04 c : </h2>
    <form action="" method="post">
    <table>
    <tr>
        <td><label for="">Nom fichier :</label></td>
        <td><input type="text" name="filename" id="" value="<?php if(isset($_POST['filename'])) echo $_POST['filename']; ?>" ></td>
        <td><label for="">Nom fichier reverser :</label></td>
        <td><input type="text" name="name" id="" value="<?php if(isset($_POST['filename'])) echo $_POST['filename']; ?>" ></td>
        <td><input type="submit" value="ok" name="ok"></td>
    </tr>
    </table>
    <table>
        <tr>
            <td><?php 
        if(isset($_POST['ok'])){
          inverserFichier1($_POST['filename'],$_POST['name']); 
        }  ?></td>
        </tr>
    </table>
    </form>
</body>
</html>