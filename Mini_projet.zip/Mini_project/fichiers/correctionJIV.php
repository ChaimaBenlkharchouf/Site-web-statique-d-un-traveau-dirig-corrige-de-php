<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="../Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 100%;
    align-items: center;
}
.col1{
    flex-basis: 100%;
}
.carde{
    width: 95%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 95%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}
    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="../img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="../home.php">L'accueil </a></li>
                    <li><a href="../TP.php">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="../img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2>



<mark>// Formulaire avec html: <br>      </mark>

< form action="< ?php echo $_SERVER["PHP_SELF"] ?>" method ="post"><br>
    

    < fieldset><br>
    < legend>ﬁchier texte info.txt comportant des informations d’une entreprise question (J) :< /legend><br>
    < table>
                < tr><br>
                    < td>Code  < input type="text" name="c">< /td><br>
                    < td>Nom < input type="text" name="n">< /td><br>
                    < td>Ville < input type="text" name="v">< /td><br>
                    < td>< input type="submit" name="ok" value="Ajouter">< /td><br>
                < /tr>
            < /table><br>
    < /fieldset>
    < /form> <br>
    <mark>// Code PHP Fonction  monFichier2:<br>  </mark>

            < ?php<br>
                
                $F=fopen("info.txt","a");<br>
                $filename="info.txt";<br>
                if (isset($_POST['ok'])) {<br>
                    if (filesize($filename)*0.001< 100) { <br>
                        fprintf($F,"%s\t %s\t %s\n",$_POST['c'],$_POST['n'],$_POST['v']);
                    }<br>else{
                        echo "la taille de ce fichier depasser 100ko";
                    }<br>
                    
                }
                fclose($F);<br>
                
            ?>
<br>

</div>
</div>
<div class="col1">

<div  class="carde">
<h2> Resultat :</h2><br><br><br><br>
    <center> 
    <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method ="post">
    

<fieldset>
<legend>ﬁchier texte info.txt comportant des informations d’une entreprise question (J) :</legend>
<table>
            <tr>
                <td>Code <input type="text" name="c"></td>
                <td>Nom <input type="text" name="n"></td>
                <td>Ville <input type="text" name="v"></td>
                <td><input type="submit" name="ok" value="Ajouter"></td>
            </tr>
        </table>
</fieldset>
</form>
        
        <?php
            
            $F=fopen("info.txt","a");
            $filename="info.txt";
            if (isset($_POST['ok'])) {
                if (filesize($filename)*0.001<100) {
                    fprintf($F,"%s\t %s\t %s\n",$_POST['c'],$_POST['n'],$_POST['v']);
                }else{
                    echo "la taille de ce fichier depasser 100ko";
                }
                
            }
            fclose($F);
            
        ?>
</center>
</div>

</div>

</div>
</body>
</html>
