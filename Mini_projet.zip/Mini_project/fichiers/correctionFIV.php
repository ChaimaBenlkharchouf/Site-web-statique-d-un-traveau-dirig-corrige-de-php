<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="../Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 100%;
    align-items: center;
}
.col1{
    flex-basis: 100%;
}
.carde{
    width: 90%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 90%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}
    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="../img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="../home.php">L'accueil </a></li>
                    <li><a href="../TP.php">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="../img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2>



<mark>// Formulaire avec html: <br>      </mark>
< form action="< ?php echo $_SERVER["PHP_SELF"] ?>" method ="post"><br>
    < fieldset><br>
< legend>Le nombre d'occurence question ( f && h ) :< /legend><br>
< label> Nom de fichier:< /label><br>

< input type="text" name="fiche4" >< br><br>

< label >  Contenu: < /label><br>
< textarea name="contenu4" id="" cols="30" rows="10" > < /textarea>< br><br>

< input type="text" name="char" >< br><br>
< br>< br>
< input type="submit"  name="oc"  value="Occurences"><br>
< /center>
< /fieldset>
< /form><br>
<mark>// Code PHP Fonction  monFichier2:<br>  </mark>

        < ?php <br>
   

 
function Calculer2()
{<br>
    if ( isset($_POST['fiche4']) && isset($_POST['contenu4'])) {<br>

        $fich4 =$_POST['fiche4'];
        $contenu4 =$_POST['contenu4'];
        $char =$_POST['char'];<br>

    $f=fopen("$fich4.txt", "w+") or die("error"); 
       file_put_contents("$fich4.txt",$contenu4); <br>
       if (!$f) 

    die('imppossible');<br>
    
    if(!fclose($f))
     die("Fermeture de fichier est echoue!!");<br>
     
   if(! empty($char))<br>


echo '<b>"' . $contenu4 . '"</b> contient <b>' . substr_count($contenu4, $char) . '</b> fois le :  <b>' . $char . '</b>< br>';



}}<br>

echo Calculer2();
?><br>

</div>
</div>
<div class="col1">

<div  class="carde">
<h2> Resultat :</h2><br><br><br><br>
    <center> 
    <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method ="post">
    <fieldset>
<legend>Le nombre d'occurence question ( f && h ) :</legend>
<label> Nom de fichier:</label>

<input type="text" name="fiche4" ><br><br>

<label >  Contenu: </label>
<textarea name="contenu4" id="" cols="30" rows="10" > </textarea><br><br>

<input type="text" name="char" ><br><br>
<br><br>
<input type="submit"  name="oc"  value="Occurences">
</center>
</fieldset>
</form>
        
        <?php
   

 
function Calculer2()
{
    if ( isset($_POST['fiche4']) && isset($_POST['contenu4'])) {

        $fich4 =$_POST['fiche4'];
        $contenu4 =$_POST['contenu4'];
        $char =$_POST['char'];

    $f=fopen("$fich4.txt", "w+") or die("error"); 
       file_put_contents("$fich4.txt",$contenu4); 
       if (!$f) 

    die('imppossible');
    
    if(!fclose($f))
     die("Fermeture de fichier est echoue!!");
  
   if(! empty($char))


echo '<b>"' . $contenu4 . '"</b> contient <b>' . substr_count($contenu4, $char) . '</b> fois le :  <b>' . $char . '</b><br>';



}}

echo Calculer2();
?>
</center>
</div>

</div>

</div>
</body>
</html>
