<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="../Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 100%;
    align-items: center;
}
.col1{
    flex-basis: 100%;
}
.carde{
    width: 90%;
    height: 80%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 90%;
    height: 80%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}
    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="../img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="../home.php">L'accueil </a></li>
                    <li><a href="">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="../img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2>




    < form action="< ?php echo $_SERVER["PHP_SELF"] ?>" method ="post"><br>
< fieldset><br>
< legend>les question a,b et c :< /legend><br>
< label> Nom de fichier:< /label><br>

< input type="text" name="fiche" ><br>

< label >  Contenu: < /label><br>
< textarea name="contenu" id="" cols="30" rows="10" > < /textarea><br>
< br>< br>
< input type="submit"  name="chr"  value="Afficher"><br>

< /center><br>
< /fieldset><br>
< /form><br>
        
         < ? php<br>
   
if ( isset($_POST['chr'])){<br>
    $fich =$_POST['fiche'];
    $cnt=$_POST['contenu'];<br>
    function creerFichier($fich,$cnt){<br>
    if ( isset($_POST['fiche']) && isset($_POST['contenu'])) {<br>
      
      
       $id = fopen("$fich.txt", "w+");<br>
    
      file_put_contents("$fich.txt",$cnt);<br>
    
    if (!$id) <br>
    die('imppossible');<br>
    
    if(!fclose($id))<br>
     die("Fermeture de fichier est echoue!!");
    
    } 
    }<br>
    function afficherFichier($cnt){
        echo $cnt ;
    }<br>
    
    
    echo creerFichier($fich,$cnt);<br>
    echo afficherFichier($cnt); <br>
    
    }
?><br>





</div>
</div>
<div class="col1">

<div  class="carde">
<h2> Resultat :</h2><br><br><br><br>
    <center> 
    <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method ="post">
<fieldset>
<legend>les question a,b et c :</legend>
<label> Nom de fichier:</label>

<input type="text" name="fiche" ><br><br>

<label >  Contenu: </label>
<textarea name="contenu" id="" cols="30" rows="10" > </textarea>
<br><br>
<input type="submit"  name="chr"  value="Afficher"><br><br>

</center>
</fieldset>
</form>
        
        <?php
   
if ( isset($_POST['chr'])){
    $fich =$_POST['fiche'];
    $cnt=$_POST['contenu'];
    function creerFichier($fich,$cnt){
    if ( isset($_POST['fiche']) && isset($_POST['contenu'])) {
      
      
       $id = fopen("$fich.txt", "w+");
    
      file_put_contents("$fich.txt",$cnt);
    
    if (!$id) 
    die('imppossible');
    
    if(!fclose($id))
     die("Fermeture de fichier est echoue!!");
    
    } 
    }
    function afficherFichier($cnt){
        echo $cnt ;
    }
    
    
    echo creerFichier($fich,$cnt);
    echo afficherFichier($cnt); 
    
    }
?>
</center>
</div>

</div>

</div>
</body>
</html>
