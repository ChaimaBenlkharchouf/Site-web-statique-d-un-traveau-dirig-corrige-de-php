<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="../Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 100%;
    align-items: center;
}
.col1{
    flex-basis: 100%;
}
.carde{
    width: 95%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 95%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}
    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="../img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="../home.php">L'accueil </a></li>
                    <li><a href="../TP.php">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="../img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2>



<mark>// Formulaire avec html: <br>      </mark>
< form action="< ?php echo $_SERVER["PHP_SELF"] ?>" method ="post"><br>
    

< fieldset><br>
< legend> Taperez le nombre a rechercher  (K) :< /legend><br>
<  table>
    < tr><br>
        < td>< label for="">Nombre a rechercher :< /label></ td><br>
        < td>< input type="text" name="filename" id="" value="< ?php if(isset($_POST['filename'])) echo $_POST['filename']; ?>" >< /td><br>
        < td>< input type="submit" value="Chercher" name="ok">< /td><br>
    < /tr>
    </ table><br>
    < table>
        < tr><br>
             < td>< ?php <br>
        if(isset($_POST['ok'])){<br>
          Recherche($_POST['filename']); <br>
        }  ?>< /td><br>
        < /tr>
    < /table><br>
< /fieldset>
< /form><br>
        <mark>// Code PHP Fonction  monFichier2:<br>  </mark>


< ?php <br>
function Recherche($n){<br>
    $F=fopen("info.txt","r");<br>
    do
    {fscanf($F,"%s\t %s\t %s\n",$E,$Et,$Etu);<br>
        if ($n == $E)<br>
        {         
      printf(" Code client :%s\t ",$E);<br>
      printf(" Nom client : %s\t ",$Et);<br>
      printf(" Ville client : %s\t ",$Etu);<br>
        }
    }while(!feof($F));<br>
    fclose($F);<br>
}  
?><br>

    

<br>

</div>
</div>
<div class="col1">

<div  class="carde">
<h2> Resultat :</h2><br><br><br><br>
    <center> 
    <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method ="post">
    

<fieldset>
<legend> Taperez le nombre a rechercher  (K) :</legend>
<table>
    <tr>
        <td><label for="">Nombre a rechercher :</label></td>
        <td><input type="text" name="filename" id="" value="<?php if(isset($_POST['filename'])) echo $_POST['filename']; ?>" ></td>
        <td><input type="submit" value="Chercher" name="ok"></td>
    </tr>
    </table>
    <table>
        <tr>
            <td><?php 
        if(isset($_POST['ok'])){
          Recherche($_POST['filename']); 
        }  ?></td>
        </tr>
    </table>
</fieldset>
</form>
        
<?php 
function Recherche($n){
    $F=fopen("info.txt","r");
    do
    {fscanf($F,"%s\t %s\t %s\n",$E,$Et,$Etu);
        if ($n == $E)
        {         
      printf(" Code client :%s\t ",$E);
      printf(" Nom client : %s\t ",$Et);
      printf(" Ville client : %s\t ",$Etu);
        }
    }while(!feof($F));
    fclose($F);
}  
?>
</center>
</div>

</div>

</div>
</body>
</html>
