<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="../Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 100%;
    align-items: center;
}
.col1{
    flex-basis: 100%;
}
.carde{
    width: 90%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 90%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}
    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="../img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="../home.php">L'accueil </a></li>
                    <li><a href="../TP.php">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="../img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2>



// Formulaire avec html: <br>
< form action="< ?php echo $_SERVER["PHP_SELF"] ?>" method ="post"><br>
< fieldset><br>
< legend>La question d (copy) :< /legend><br>
< label> Nom de fichier copie:< /label><br>

< input type="text" name="fiche1" >< br><br>
Contenu
< textarea name="cnt" id="" cols="30" rows="10" > < /textarea>< br><br>

< label > Nom de fichier coller : < /label><br>
< input type="text" name="fiche2" >< br><br>

< input type="submit"  name="copy"  value="Valider"><br>
< /fieldset><br>


< /fieldset><br>
< /form><br>
      // Code PHP Fonction  monFichier2:<br>
        < ?php<br>
   
if ( isset($_POST['copy'])){<br>


    function monFichier2(){ <br>  
   $fich1 =$_POST['fiche1'];
    $fich2=$_POST['fiche2'];<br>
    if ( isset($_POST['fiche1']) && isset($_POST['fiche2'])) {<br>
     
       
        
    $a="C:\\xampp\htdocs\Mini_Project\\fichiers\\$fich1.txt";<br>
    $b="C:\\xampp\htdocs\Mini_Project\\fichiers\\$fich2.txt"; <br> 
    $f = fopen("$fich1.txt", "w+");<br>
  
    $txt=$_POST['cnt'];<br>
    fwrite($f,$txt);<br>
    if (!copy($a,$b)) 
{  
echo "Fichier non copié";  
}  <br>
else 
{  
echo "Fichier correctement copié";  
}  <br>

if (!$f) 
die('imppossible');<br>

if(!fclose($f))
die("Fermeture de fichier est echoue!!");


    }
}<br>
echo monFichier2();
}<br>
? ><br>

</div>
</div>
<div class="col1">

<div  class="carde">
<h2> Resultat :</h2><br><br><br><br>
    <center> 
    <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method ="post">
<fieldset>
<legend>La question d (copy) :</legend>
<label> Nom de fichier copie:</label>

<input type="text" name="fiche1" ><br><br>
Contenu
<textarea name="cnt" id="" cols="30" rows="10" > </textarea><br><br>

<label > Nom de fichier coller : </label>
<input type="text" name="fiche2" ><br><br>

<input type="submit"  name="copy"  value="Valider"><br>
</fieldset>


</fieldset>
</form>
        
        <?php
   
if ( isset($_POST['copy'])){


    function monFichier2(){   
   $fich1 =$_POST['fiche1'];
    $fich2=$_POST['fiche2'];
    if ( isset($_POST['fiche1']) && isset($_POST['fiche2'])) {
     
       
        
    $a="C:\\xampp\htdocs\Mini_Project\\fichiers\\$fich1.txt";
    $b="C:\\xampp\htdocs\Mini_Project\\fichiers\\$fich2.txt";  
    $f = fopen("$fich1.txt", "w+");
  
    $txt=$_POST['cnt'];
    fwrite($f,$txt);
    if (!copy($a,$b)) 
{  
echo "Fichier non copié";  
}  
else 
{  
echo "Fichier correctement copié";  
}  

if (!$f) 
die('imppossible');

if(!fclose($f))
die("Fermeture de fichier est echoue!!");


    }
}
echo monFichier2();
}
?>
</center>
</div>

</div>

</div>
</body>
</html>
