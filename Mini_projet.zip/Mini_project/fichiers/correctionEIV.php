<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="../Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 100%;
    align-items: center;
}
.col1{
    flex-basis: 100%;
}
.carde{
    width: 90%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 90%;
    height: 100%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}
    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="../img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="../home.php">L'accueil </a></li>
                    <li><a href="../TP.php">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="../img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2>



<mark>// Formulaire avec html: <br>      </mark>

< form action="< ?php echo $_SERVER["PHP_SELF"] ?>" method ="post"><br>

< fieldset><br>
< legend>Les voyelles question (e) :< /legend><br>
< label> Nom de fichier:< /label><br>

< input type="text" name="fiche3" ><br>

< label >  Contenu: < /label><br>
< textarea name="contenu3" id="" cols="30" rows="10" > < /textarea>
< br><br>

< input type="submit"  name="vyll"  value="Voyelles & consonnes">
< /center><br>
< /fieldset>
< /form><br>
      <mark>// Code PHP Fonction  monFichier2:<br>  </mark>
    < ?php<br>


if ( isset($_POST['vyll'])){<br>

function Calculer1(){<br>
    if ( isset($_POST['fiche3']) && isset($_POST['contenu3'])) {<br>

    $fich3 =$_POST['fiche3'];
    $contenu =$_POST['contenu3'];<br>
$f=fopen("$fich3", "w+") or die("error");<br>
  
  
   
 
   file_put_contents("$fich3.txt",$contenu);<br>

    
if (!$f) 
die('imppossible');<br>

if(!fclose($f))
 die("Fermeture de fichier est echoue!!");<br>

    $tab = array('a', 'e', 'i', 'o', 'u', 'y');
    $tot = 0;<br>

    foreach($tab as $voyelle){
    $tot += substr_count(strtolower($contenu), $voyelle);
      
     }<br>
    echo $tot.' voyelles'; // Affiche : 6 voyelles
 echo "<br/>";<br>

 $a =strlen($contenu) - (substr_count($contenu, ' ' ));<br>

echo $a - $tot ." consonnes";<br>

}
}
echo Calculer1();<br>
}
?><br>

</div>
</div>
<div class="col1">

<div  class="carde">
<h2> Resultat :</h2><br><br><br><br>
    <center> 
    <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method ="post">

    <fieldset>
<legend>Les voyelles question (e) :</legend>
<label> Nom de fichier:</label>

<input type="text" name="fiche3" >

<label >  Contenu: </label>
<textarea name="contenu3" id="" cols="30" rows="10" > </textarea>
<br><br>

<input type="submit"  name="vyll"  value="Voyelles & consonnes">
</center>
</fieldset>
</form>
        
        <?php
   

   if ( isset($_POST['vyll'])){

    function Calculer1(){
        if ( isset($_POST['fiche3']) && isset($_POST['contenu3'])) {
    
        $fich3 =$_POST['fiche3'];
        $contenu =$_POST['contenu3'];
    $f=fopen("$fich3", "w+") or die("error");
      
      
       
     
       file_put_contents("$fich3.txt",$contenu);
    
        
    if (!$f) 
    die('imppossible');
    
    if(!fclose($f))
     die("Fermeture de fichier est echoue!!");
    
        $tab = array('a', 'e', 'i', 'o', 'u', 'y');
        $tot = 0;
    
        foreach($tab as $voyelle){
        $tot += substr_count(strtolower($contenu), $voyelle);
          
         }
        echo $tot.' voyelles'; // Affiche : 6 voyelles
     echo "<br/>";
    
     $a =strlen($contenu) - (substr_count($contenu, ' ' ));
    
    echo $a - $tot ." consonnes";
    
    }
    }
    echo Calculer1();
    }
?>
</center>
</div>

</div>

</div>
</body>
</html>
