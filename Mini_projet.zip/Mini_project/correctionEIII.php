<?php
          include "function.php";
 ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="Style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <style>

.row1{
    display: flex;
    height: 1740px;
    align-items: center;
}
.col1{
    flex-basis: 100%;
}
.carde{
    width: 90%;
    height: 80%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
    
}
.carde1{
    width: 90%;
    height: 80%;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
  
    margin: 10px 15px;
   background-color: #F9EBEA;
    background-position: center;
    background-size: cover;
  
}

    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
            <img src="img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li><a href="home.php">L'accueil </a></li>
                    <li><a href="TP.php">Traveau Pratique</a></li>
                    <li><a href="">Cours PHP</a></li>
                </ul>
            </nav>
            <img src="./img/menu.jpg" class="menu-icon" >
        </div>
<div class="row1">
    <div class="col1">
<div class="carde">
<h2> Code sourece</h2>
<br>
<center>
   <div >  
   <br><br> <pre>
   < table align="center"><br>
    < form action="" method="POST"><br>
        < tr>< td>TXT:< /td> <  td>< input type="text" name="txt"></ td>< /tr><br>
         < tr>< td>< /td> < td> < input type="submit" name="ok">< /td>< /tr><br>


     < /form><br>
     <br> < ?php
         if(isset($_POST['ok'])){
                
                echo" < tr>< td>RLE:<  /td> < td>< input type=text name=txt value=".CodageRLE($_POST['txt']).">< /td>< /tr>" ;
    }<br>
   
     ?><br>
 < /table>

 < ?php
 
 
function CodageRLE($txt)
    {
               $tab=str_split($txt);
                $n=0;
                $var="";
                do{
                $rep=Rpetition($txt,$n);
                $var=$var.$rep.$tab[$n];
                $n=$n+$rep;

                }while($n< count($tab));
                return $var;
            }
            
function Rpetition($txt,$a)
		 {	   
		 	    
				$nbr=0;
				$tab = str_split($txt);
                $indice=$tab[$a];
                for($i=$a;$i< count($tab);$i++){
                	if($tab[$i]!=$indice) {
                		break;			}

                		$nbr++;

												}
                
			 return $nbr;
									
								}
function Entier($txt,$a)
            {
            	$tab = str_split($txt);
                 $contenu=$tab[$a];
                 $var="";
                 $nbr=0;
                 if (is_numeric($contenu)) {
                     for($i=$a;$i< count($tab);$i++){
                	    if(is_numeric($tab[$i])){ 
                	    	 $nbr++;
                	    	$var=$var.$tab[$i]; }		
                	    else{
                	    	$table=array($var,$nbr);
                		    return $table; 
                		  }	
                		
									}
									}
				 else{
				 	     $table=array(0,0);

							return $table;
							
								}
					  	    	$table=array($var,$nbr);
								return $table;
}
 ? >
</pre>
<br>

</div>
</center>
</div>
</div>
<div class="col1">
<div  class="carde">
<h2> Resultat :</h2><br> 


<table align="center">
    <form action="" method="POST">
        <tr><td>TXT:</td> <td><input type="text" name="txt"></td></tr>
         <tr><td></td> <td> <input type="submit" name="ok"></td></tr>


     </form>
     <?php
         if(isset($_POST['ok'])){
                
                echo" <tr><td>RLE:</td> <td><input type=text name=txt value=".CodageRLE($_POST['txt'])."></td></tr>" ;
    }
   
     ?>
 </table>
</div>

</div>

</div>


</body>
</html>
