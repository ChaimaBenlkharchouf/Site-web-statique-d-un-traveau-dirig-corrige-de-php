<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
   
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

    <Style>
 *{
    margin: 0;
    padding: 0;
    font-family: 'Roboto' sans-serif;
}
body{background:#F9EBEA;}
.container{
    width: 100%;
    height: 100vh;
    
    background-position: center;
    background-size: cover;
    padding-left: 8%;
    padding-right: 8%;
    box-sizing: border-box;
}
.navbar{
    height: 12%;
    display: flex;
    align-items: center;
}
.logo{
    width: 50px;
    cursor: pointer;
}
.menu-icon{
    width: 30px;
    cursor: pointer;
    margin-left: 40px;
}
nav{
    flex: 1;
    text-align: right;
}
nav ul li{
    list-style: none;
    display: inline-block;
    margin-left: 60px;
}
nav ul li a{
    text-decoration: none;
    color: rgb(0, 0, 0);
    font-size: 13px;
}
.row{
    display: flex;
    height: 88%;
    align-items: center;
}
.col{
    flex-basis: 50%;
}
h1{
    color: #000;
    font-size: 100px;
}
p{
    color: #000;
    font-size: 11px;
    line-height: 15px;
}
button{
    width: 180px;
    color: #000;
    font-size: 12px;
    padding: 12px 0;
    background: rgb(9, 130, 167);
    border: 0;
    border-radius:  20px;
    outline: none;
    margin-top: 30px;
}
.card{
    width: 200px;
    height: 230px;
    display: inline-block;
    border-radius: 10px;
    padding: 15px 25px ;
    box-sizing: border-box;
    cursor: pointer;
    margin: 10px 15px;
   
    background-position: center;
    background-size: cover;
    transition: transform 0.5s;
}
.card1{
    background-image: url("img/var.png");
}
.card2{
    background-image: url("img/var.png");
}
.card3{
    background-image: url("img/var.png");
}
.card4{
    background-image: url("img/var.png");
}
.card:hover{
    transform: translateY(-10px);
}
h5{
    color: #fff;
   text-shadow: 0 0 5px #999; 
}
.card p{
    text-shadow: 0 0 5px #000;
    font-size: 8px; 
}
        </Style>
</head>
<body > 
<div class="container">
        <div class="navbar">
            <img src="img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                <li><a href="home.php">L'accueil </a></li>
                    <li><a href="#var"> Variable</a></li>
                    <li><a href="#tab">Tableau</a></li>
                    <li><a href="#fct">Fonction</a></li>
                    <li><a href="#fich">Fichier</a></li>
                    <li><a href="#sql">Sql</a></li>
                </ul>
            </nav>
            <img src="img/menu.jpg" class="menu-icon" >
        </div>

        <pre>

     
                <h2 id="var">Variables :</h2>
                Considérons les variables $Licences = 3 ; $Masters = 2 ;
                Afficher, à l’aide d’une seule instruction PHP, la phrase suivante :
                J’ai 3 Licences et 2 Masters, j’ai donc 5 formations.
                Les nombres 3, 2 et 5 dépendent des valeurs des variables données précédemment. Le faire
                une fois en utilisant uniquement les apostrophes et une fois en utilisant uniquement les
                guillemets <br>
                <center> <button> <a href="correction.php" >Corrigé</a> </button></center>
                    <br>

                   <h2 id="tab"> Conditions, Boucles et Tableaux :</h2>
                Considérons par exemple les variables suivantes :
                $Ville = ’Tanger’ ;
                $TempVille = 23 ;
                $TabCouleurs = array(’Rouge foncé’, ’Rouge’, ’Ecarlate’, ’Orange’, ’Jaune’, ’Vert riche’,
                ’Vert’, ’Bleu ciel’, ’Bleu’, ’Violet’, ’Violet rose’, ’Magenta’) ;
                Afficher, à l’aide d’une boucle et des instructions if...else...elseif et switch, la table
                HTML suivante :<br>
                <center><img src="img/variable.jpg" >
                <br>L’affichage dans la table dépend des valeurs des variables données précédemment.<br></center>

                <center> <button> <a href="correctionII.php" >Corrigé</a> </button></center>

                <br>

                    <br>

                    <h2 id="fct">  Fonctions :</h2><BR>
                    <h4> { A } :</h4>

                    Ecrire une fonction NomComplet qui prend en paramètre deux chaines de caractères à
                     partir de deux zones de texte Nom et Prenom puis construit et retourne
                    une chaîne de caractères représentant le nom complet dans une troisième zone de
                    texte<br>
                    Exemple :<br>
                    <center><img src="img/FCTT.jpg" >
                    </center><BR>

                    <center> <button> <a href="correctionAIII.php" >Corrigé</a> </button><br><br><br></center>
                   

                   
                    <h4>{ B } :</h4><br>

                    Ecrire une fonction Remplacer qui prend en paramètre une chaine de caractères
                    TXT et deux lettres X et Y puis retourne une chaine de caractères RES où toutes
                    les apparitions du caractère X sont remplacées par Y.<br>
                                        Exemple :<br>
                    <center><img src="img/FCTTB.jpg" >
                    </center><BR>

                    <center> <button> <a href="correctionBIII.php" >Corrigé</a> </button><br><br><br>  </center>  
                  
                    
                    <h4>{ C } :</h4><br>
                    Ecrire une fonction Rpetition qui prend en paramètre une chaine de caractères
                    TXT et un entier i puis retourne le nombre de répétitions continues dans TXT à
                    partir de l’indice i.
                    <br>
                                        Exemple :<br>
                    <center><img src="img/FCTTC.jpg" >
                    </center><BR>

                    <center> <button> <a href="correctionCIII.php" >Corrigé</a> </button><br><br><br>  </center>  


                    <h4>{ D } :</h4><br>
                    Ecrire une fonction Entier qui prend en paramètre une chaine de caractères TXT
                    et un indice i puis retourne l’entier RES correspondant à tous les chiffres continues
                    à partir de la case d’indice i ainsi que nbr le nombre de chiffres lus
                    <br>
                                        Exemple :<br>
                    <center><img src="img/FCTTD.jpg" >
                    </center><BR>

                    <center> <button> <a href="correctionDIII.php" >Corrigé</a> </button><br><br><br>  </center>  

                    <h4>{ E } :</h4><br>
                    Afin d’économiser l’espace de stockage, on utilise souvent des algorithmes de compression. 
                    Parmi les algorithmes les plus utilisés on trouve l’algorithme de codage
                    RLE vu la facilité de le programmer.
                    Le principe est simple, au lieu d’écrire :
                    wwwwwwwwwwwwbaaaabbbccccccbww.
                    Il vaut mieux écrire : 12w1b4a3b6c1b2w.
                    C’est-à-dire remplacer chaque répétition d’un caractère par le nombre de répétitions
                    suivi du caractère répété. <br>
                    Ecrire une fonction CodageRLE qui reçoit en paramètres une chaine de caractères
                    TXT et retourne son codage RLE. On suppose que la chaine TXT ne contient
                    pas de chiffres.
                    <br>
                                        Exemple :<br>
                    <center><img src="img/FCTTE.jpg" >
                    </center><BR>

                    <center> <button> <a href="correctionEIII.php" >Corrigé</a> </button><br><br><br>  </center>  


                    
                    <h4>{ F } :</h4><br>
                    Ecrire une fonction DecodageRLE qui reçoit en paramètres une chaine de caractères codée en RLE et retourne le texte décodé TXT.

                    <br>
                                        Exemple :<br>
                    <center><img src="img/FCTTF.jpg" >
                    </center><BR>

                    <center> <button> <a href="correctionFIII.php" >Corrigé</a> </button><br><br><br>  </center>  



                    <br>

                    <br>

                    <h2 id="fich"> Les Fichiers :</h2><BR>
                    <h4> { A } :</h4>

                    Ecrire une fonction creerFichier qui reçoit en paramètre un nom de fichier ch reçu
                    d’une zone de texte. Ensuite cette fonction permet d’écrire dans ce fichier le texte
                    suivant d’une autre zone de texte :
                        <br>
                    Exemple :<br>
                    <center><img src="img/fichA.jpg" >
                    </center><BR>



                    <h4> { B } :</h4>
                    Ecrire une fonction afficherFichier qui permet de lire et d’afficher le texte déjà
                    écrit dans l’exercice précédent.:
                        <br>
                    <br>
                     <h4> { C } :</h4>
                    Ecrire une fonction monFichier1(ch) qui reçoit en paramètre un nom de fichier.
                    Si le fichier n’esxiste pas, la fonction permet de créer et d’enregistrer de nouvelles
                    lignes. Sinon, la fonction sert à afficher le contenu du fichier.
                                            <br>
                    <br>
                    <center> <button> <a href="./fichiers/correctionAIV.php" >Corrigé</a> </button><br><br><br></center>
                     <h4> { D } :</h4>
                     Ecrire une fonction monFichier2(ch1, ch2) qui lit le contenu du fichier ch1 et le
                     recopie dans un autre fichier ch2.
                        <br>
                    <br>
                     <center> <button> <a href="./fichiers/correctionDIV.php" >Corrigé</a> </button><br><br><br></center>


                     <br>
                    <br>

                     <h4> { E } :</h4>
                     Ecrire une fonction Calculer1(ch) qui calcule et affiche le nombre de voyelles, et
                     le nombre de consonnes d’un fichier texte
                        <br>
                  
                        
                     <center> <button> <a href="./fichiers/correctionEIV.php">Corrigé</a> </button><br><br><br></center>


                     <br>
                  

                    <h4> { F } :</h4>
                     Ecrire une fonction Calculer2(ch) analysant un fichier texte et indiquant le nombre
                     d’occurrence de caractères et de chiffres.
                        <br>
                    <br>


                     <h4> { H } :</h4>
                    Ecrire une fonction chercherMot(ch, mot) analysant un fichier texte ch et indiquant le nombre d’occurrences d’un mot mot,
                     donné en paramètre de la fonction
                    dans ch.
                
                    <br>
                    <center> <button> <a href="./fichiers/correctionFIV.php" >Corrigé</a> </button><br><br><br></center>




                    <h4> { G } :</h4>
                    Ecrire une fonction Calculer3(ch) qui calcule le nombre de lettres, de chiffres et
                    de lignes d’un fichier texte
                    Remarques : Le résultat doit être classé en ordre croissant et enregistré dans un
                    fichier Resultat.txt.

                    <br>
                     <center> <button> <a href="./fichiers/correctionGIV.php"  >Corrigé</a> </button><br><br><br></center>


                     <br>
                    <br>


                    <h4> { I } :</h4>
                    Ecrire une fonction inverserFichier() permettant de recopier le contenu d’un fichier texte à l’envers et le mets dans un deuxième fichier
                    modifier la fonction pour qu’il recopie à l’envers mot par mot.
                        <br>
                    <br>
                    <center> <button> <a href="./fichiers/correctionIIV.php" >Corrigé</a> </button><br><br><br></center>


                     <br>
                    <br>

                    <h4> { J } :</h4>
                     Ecrire une fonction chargerFichier1() qui permet de créer un fichier texte info.txt
                     comportant des informations d’une entreprise sous la forme suivante :
                     <Code client> <Nom client> <Ville client>

                     <br>
                    Exemple :<br>
                    <center><img src="img/fichJ.jpg" ><br>
                  
                    </center><BR>
  Remarques :
                        — Ces informations seront lues à partir des zones de textes.
                        — La fonction vérifie la taille du fichier. Si le fichier dépasse 100 Ko, un message d’erreur s’affiche.
                    <center> <button> <a href="./fichiers/correctionJIV.php" >Corrigé</a> </button><br><br><br></center>


                    <br>
                    <br>

                    <h4> { K } :</h4>
                    Ecrire une fonction chercherCode(code) permettant, à partir du fichier créé par
                    la question précédente, de retrouver les informations correspondant à un code de
                    client reçu comme paramètre et à partir d’une zone de texte
                        <br>
                    <br>
                     <center> <button> <a href="./fichiers/correctionKIV.php"  >Corrigé</a> </button><br><br><br></center>


                     <br>
                    <br>

                    <h4> { L } :</h4>
                    Ecrire une fonction chargerFichier2() qui charge et retourne les informations du
                    fichier de la question (e) dans une table associative info de la forme suivante :
                    array(<Code client> => array ( <Nom client>, <Ville client> )).
                        <br>
                    <br>
                    <center> <button> <a href="./fichiers/correctionLIV.php"  >Corrigé</a> </button><br><br><br></center>


                     <br>
                    <br>

                    <h4> { M } :</h4>
                    Ecrire une fonction compterVille(V, info) qui reçoit une chaine de caractères V
                    à partir d’une zone de texte et la table info de la question précédente, puis qui
                    compte et affiche combien d’articles sont destinés à être distribuer dans la ville V.
                        <br>
                    <br>
                    <center> <button> <a href="./fichiers/correctionMIV.php" >Corrigé</a> </button><br><br><br></center>


                     <br>
                    <br>

                    <h4> { N } :</h4>
                    Ecrire une fonction distrubuerVille(Info) qui reçoit comme paramètre la table
                    Info puis enregistre les informations des produits de chaque ville dans un fichier àpart.
                     
                       
                    Exemple :  Pour la table info.
                    <center><img src="img/fichN.jpg" >
                  
                    </center>
                
                    <center> <button> <a href="./fichiers/correctionNIV.php" >Corrigé</a> </button><br><br><br></center>

<br>

<h2 id="sql"> (V) PHP et MySQL  :</h2><BR>


Soient les tables suivantes d’une base de donnée qu’on appellera GestionNotes :
 — Etudiants (CNE, nom, #codeClasse) : — CNE : code national de l’étudiant, de type TEXT, clé primaire. — nom : nom de l’étudiant, de type TEXT.
 — codeClasse : donnée de type TEXT, clé étrangère.
 — Classes (codeClasse, ﬁliere, num) : — codeClasse : code déﬁnissant de manière unique une classe, de type TEXT, clé primaire.
 — ﬁliere : donnée de type TEXT désignant la ﬁlière d’une classe. — num : donnée de type INTEGER désignant le numéro d’une classe.
 — Matieres (codeMat, designation) : — codeMat : code déﬁnissant de manière unique une matière, de type TEXT, clé primaire.
 — designation : donnée de type TEXT désignant la désignation d’une matière. 
 — Notes (#codeMat, #CNE, note) : — codeMat : clé étrangère. — CNE : clé étrangère.  
    —  note : donnée de type REAL désignant la note d’un étudiant pour une matière donnée. 
    
    (a) Créer la base de donnée GestionNotes avec ses tables. 
    (b) En utilisant des scripts PHP d’un back oﬃce (côté administration) :
         — Alimenter les tables par des données convenables. 
         — Visualiser, modiﬁer et supprimer certains enregistrements de chaque table.

    (c) EnutilisantdesscriptsPHPd’unfrontoﬃce(côtéclient),créercettepagebulletin:

    <br>


    <center> <button> <a href="../ex_pdo/BSD.php" >Corrigé</a> </button><br><br><br></center>



            </pre>
            
    </div>


</body> 
</html>