<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Projet</title>
    <link rel="stylesheet" href="Style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">

</head>
<body>

    <div class="container" style="background-image: url('img/bac4.jpg');">
        <div class="navbar">
            <img src="img/logo.jpg" class="logo" width="50" height="50">
            <nav>
                <ul>
                    <li ><a href="home.php">L'accueil </a></li>
                    <li ><a href="tp.php">Traveau Pratique</a></li>
                    <li ><a href="cours.pdf"  target="_blank"> Cours PHP</a></li>
                </ul>
            </nav>
            <img src="img/menu.jpg" class="menu-icon" >
        </div>
        <div class="row">
            <div class="com">
                <h1>Traveau Pratique   </h1>
                    <p> Dans cette série.........
                    Dans cette série........ Dans cette série........
                    </p>
                    <button type="button">Explore</button>
            </div>
            <div class="col">
                <div class="card card1">
                    <h5 id='up'>Les variables</h5>
                    <p>Une petite rappel sur les varibles</p>
                    <br><br><br><br>
                    <button ><a href="TP.php?#var">TP: Varible</a></button>
                </div>
                <div class="card card2">
                    <h5>Les tableaux</h5>
                    <p>Une petite rappel sur les varibles</p>
                    <br><br><br><br>
                    <button ><a href="TP.php?#tab">TP: Varible</a></button>
                </div>
                <div class="card card3">
                    <h5>Les fichiers</h5>
                    <p>Une petite rappel sur les varibles</p>
                    <br><br><br><br>
                    <button ><a href="TP.php?#fich">TP: Varible</a></button>
                </div>
                <div class="card card4">
                    <h5>SQL</h5>
                    <p>Une petite rappel sur les varibles</p>
                    <br><br><br><br>
                    <button ><a href="TP.php?#sql">TP: Varible</a></button>
                </div>
            </div>
        </div>
    </div>



</body>
</html>